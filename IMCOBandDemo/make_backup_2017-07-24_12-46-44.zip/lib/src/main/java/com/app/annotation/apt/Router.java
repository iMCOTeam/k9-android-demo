package com.app.annotation.apt;

/**
 * Created by baixiaokang on 16/12/30.
 */
//@Retention(RetentionPolicy.SOURCE)
//@Target(ElementType.TYPE)
//public @interface Router {
//    String value();
//}
