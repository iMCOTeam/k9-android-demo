package com.example.imco.mvp.main;

import android.content.Context;
import android.util.Log;

import com.App;
import com.app.annotation.apt.InstanceFactory;
import com.example.utils.LogUtils;
import com.imco.interactive.SPWristbandConfigInfo;
import com.imco.interactivelayer.manager.CommandManager;
import com.imco.interactivelayer.manager.ConnectManager;
import com.imco.interactivelayer.manager.ControlManager;
import com.imco.interactivelayer.manager.ControlManagerCallback;
import com.imco.interactivelayer.manager.SendCommandCallback;
import com.imco.protocollayer.applicationlayer.ApplicationLayer;
import com.imco.protocollayer.applicationlayer.ApplicationLayerAlarmPacket;
import com.imco.protocollayer.applicationlayer.ApplicationLayerAlarmsPacket;
import com.imco.protocollayer.applicationlayer.ApplicationLayerSleepItemPacket;
import com.imco.protocollayer.applicationlayer.ApplicationLayerSleepPacket;
import com.imco.protocollayer.applicationlayer.ApplicationLayerSportItemPacket;
import com.imco.protocollayer.applicationlayer.ApplicationLayerSportPacket;
import com.imco.protocollayer.applicationlayer.ApplicationLayerTodaySumSportPacket;
import com.realsil.android.blehub.dfu.ImcoOtaCallback;
import com.realsil.android.blehub.dfu.RealsilDfu;

import java.util.ArrayList;
import java.util.Calendar;

import io.reactivex.Observable;
import io.reactivex.ObservableOnSubscribe;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.schedulers.Schedulers;

/**
 * Created by mai on 17-6-22.
 */

@InstanceFactory
public class MainPresenter extends MainContract.MainPresenter {
    private final static String TAG = "MainPresenter";
    private ControlManager mControlManager;
    private ConnectManager mConnectManager;
    private ControlManagerCallback mControlManagerCallback;

    @Override
    public void onAttached() {
        LogUtils.d(TAG, "onConnectionStateChange, status: ");

        mControlManager = ControlManager.getInstance();
        mConnectManager = ConnectManager.getInstance();
        mConnectManager.registerCallback(new ConnectManager.BackgroundScanCallback() {
            @Override
            public void connectStatus(boolean succeeded, int code) {
                super.connectStatus(succeeded, code);
                LogUtils.d(TAG, "connectStatus, code: " + code);
                if (succeeded) {
                    mView.connecting(code);
                    switch (code) {
                        case ControlManager.STATE_WRIST_LOGING:
                            // When the bracelet is disconnected, all callbacks are cleared
                            // So need to re-register the callback when connect the bracelet again
                            mControlManager.registerCallback(mControlManagerCallback);
                            break;
                        case ControlManager.STATE_WRIST_BONDING:

                            break;
                        case ControlManager.STATE_WRIST_LOGIN:

                            CommandManager.readBatteryLevel(null);
                            CommandManager.setTimeSync(null);
                            CommandManager.sendDataRequest(null);
                            break;
                    }
                } else {
                    mView.connectError(code);
                }
            }
        });

        mControlManagerCallback = new ControlManagerCallback() {
            @Override
            public void onConnectionStateChange(final boolean status) {
                LogUtils.d(TAG, "onConnectionStateChange, status: " + status);
            }

            @Override
            public void onSportDataCmdHistorySyncEnd(ApplicationLayerTodaySumSportPacket packet) {
                LogUtils.d(TAG, "onSportDataCmdHistorySyncEnd>>>>>>>>>>>1" );

                mView.getContentStatus(mConnectManager.isConnect());
                mView.getCurrentStep(packet.getTotalStep());
                mView.getCalorie(packet.getTotalCalory());
                mView.getDistance(packet.getTotalDistance());
            }
            @Override
            public void onSportDataCmdHistorySyncEnd(ApplicationLayerSportPacket packet) {
                mView.getContentStatus(mConnectManager.isConnect());
                if (packet.getSportItems().size() > 0) {
                    ApplicationLayerSportItemPacket itemPacket = packet.getSportItems().get(0);
                    LogUtils.d(TAG, "onSportDataCmdHistorySyncEnd >>>>>>>>>>>" + itemPacket.getStepCount());
                }
            }

            @Override
            public void onSportDataReceiveIndication(ApplicationLayerSportPacket sportPacket) {
                ApplicationLayerSportItemPacket itemPacket = sportPacket.getSportItems().get(0);
                LogUtils.d(TAG, "onSportDataReceiveIndication, step: " + itemPacket.getStepCount());
                mView.getCurrentStep(itemPacket.getStepCount());
                mView.getCalorie(itemPacket.getCalory());
                mView.getDistance(itemPacket.getDistance());
            }

            @Override
            public void onSleepDataReceiveIndication(ApplicationLayerSleepPacket packet) {
                if (packet.getSleepItems().size() > 0) {
                    ApplicationLayerSleepItemPacket itemPacket = packet.getSleepItems().get(0);
                    LogUtils.d(TAG, "onSleepDataReceiveIndication >>>>>>>>>>>" + itemPacket.getMinutes());
                }
            }

            @Override
            public void onHrpDataReceiveIndication(int hrpValue) {
                mView.showHeartRate(hrpValue);
            }

            @Override
            public void onAlarmsDataReceive(ApplicationLayerAlarmsPacket data) {
                ArrayList<ApplicationLayerAlarmPacket> alarms = data.getAlarms();
                mView.alarmList(alarms);
            }

            @Override
            public void onVersionRead(int appVersion, int patchVersion) {
                mView.firmwareVersion("app version : " + appVersion + "patch version : " + patchVersion);
                LogUtils.d(TAG, "app version : " + appVersion + "patch version : " + patchVersion);
            }

            @Override
            public void noNewVersion(int code, String message) {
                LogUtils.d(TAG, "code : " + code + " message: " + message);
                mView.firmwareVersion(" message : " + message + "app code : " + code);
            }

            @Override
            public void hasNewVersion(String description, String version) {
                LogUtils.d(TAG, "description : " + description + " version : " + version);
                mView.firmwareVersion("description " + description + " version : " + version);
            }

            @Override
            public void downloadProgress(int progressRate) {
                LogUtils.d(TAG, "progressRate : " + progressRate);
            }

            @Override
            public void downloadError() {
                LogUtils.d(TAG, "netWorkError ");
            }

            @Override
            public void downloadComplete(String fwPath) {
                LogUtils.d(TAG, "fwPath : " + fwPath);
                mView.firmwarePath(fwPath);
            }
        };
        mControlManager.registerCallback(mControlManagerCallback);

    }


    @Override
    public void startSync() {
        sendCommand((e) ->e.onNext(mControlManager.setTimeSync()));
        sendCommand((e) ->e.onNext(mControlManager.sendDataRequest()));
    }

    @Override
    public void unBind() {
        sendCommand((e) ->e.onNext(mConnectManager.unbind()));
    }

    @Override
    void startAutoConnect() {
        mConnectManager.startAutoConnect();
    }

    @Override
    void stopAutoConnect() {
        mConnectManager.stopAutoConnect();
    }

    @Override
    void readHeartRate() {
        sendCommand((e) ->e.onNext(mControlManager.readHrpValue()));
    }

    @Override
    void stopReadHeartRate() {
        sendCommand((e) ->e.onNext(mControlManager.stopReadHrpValue()));
    }

    @Override
    void cycleMeasureHeartRate(boolean enable, int interval) {
        sendCommand((e) ->e.onNext(mControlManager.setContinueHrp(enable, interval)));
    }

    @Override
    void isConnected() {
        mView.getContentStatus(mConnectManager.isConnect());
    }

    @Override
    void connect() {
        sendConnectCommand((e) ->e.onNext(ConnectManager.getInstance().connect(SPWristbandConfigInfo.getBondedDevice(App.getAppContext()))));
    }

    @Override
    void initOtaProxy(Context context, ImcoOtaCallback listener) {
       CommandManager.initOtaProxy(context, listener);
    }

    @Override
    boolean ota(RealsilDfu dfu, String firmwarePath) {
        return CommandManager.startOTA(dfu, firmwarePath);
    }

    @Override
    void readBatteryLevel() {
        CommandManager.readBatteryLevel(new SendCommandCallback() {
            @Override
            public void onCommandSend(boolean status) {
                Log.d(TAG, ">>>>>>>>>>>>>>"+status);
            }

            @Override
            public void onDisConnected() {
                Log.d(TAG, ">>>>>>>>>>>>>>onDisConnected");
            }

            @Override
            public void onError(Throwable error) {
                Log.d(TAG, ">>>>>>>>>>>>>>"+error.getMessage());
            }
        });
    }


    @Override
    int getBatteryLevel() {
        return mControlManager.getBatteryLevel();
    }

    @Override
    void checkNewVersion(String vendor, String deviceType) {
        int currentFWVersion = CommandManager.getCurrentFWVersion();
        if (currentFWVersion == -1) {
                mView.getFwVersionTip();
        } else {
            CommandManager.checkNewFwVersion(vendor, deviceType);
        }
    }

    @Override
    void loadOtaFileInfo(String path) {
        mView.newOtaFileVersion(CommandManager.getOtaFileVersion(path));
    }

    @Override
    void getFwVersion() {
        sendCommand((e) -> e.onNext(mControlManager.readDfuVersion()));
    }

    @Override
    void settingAlarm(int hour, int minute, byte daysFlag, int alarmId) {
        Calendar c1 = Calendar.getInstance();
        int i = c1.get(Calendar.HOUR_OF_DAY);
        boolean dayAddFlagOne = false;
        Log.d(TAG, "syncAlarmListToRemote, hourOne: " + hour + ", minuteOne: " + minute);
        if (daysFlag == 0x00) {
            if (hour < c1.get(Calendar.HOUR_OF_DAY)) {
                dayAddFlagOne = true;
            } else if ((hour == i)
                    && (minute <= c1.get(Calendar.MINUTE))) {
                dayAddFlagOne = true;
            }
        }
        Calendar c2 = Calendar.getInstance();
        c2.add(Calendar.DATE, (dayAddFlagOne ? 1 : 0));

        ApplicationLayerAlarmPacket alarmOne =
                new ApplicationLayerAlarmPacket(c2.get(Calendar.YEAR),
                        c2.get(Calendar.MONTH) + 1,// here need add 1, because it origin range is 0 - 11;
                        c2.get(Calendar.DATE),
                        hour,
                        minute,
                        0,
                        daysFlag);

        sendCommand((e) ->e.onNext(mControlManager.stopReadHrpValue()));

        /* Can use setClocks if setting multiple alarm */
        Observable.create((ObservableOnSubscribe<Boolean>) e -> e.onNext(ControlManager.getInstance().setClock(alarmOne)))
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(aBoolean ->
                    mView.setupAlarm(aBoolean)
                , throwable -> mView.cmdError(throwable));
    }

    @Override
    void closeAlarm() {
        sendCommand((e) ->e.onNext(mControlManager.setClocks(null)));
    }

    @Override
    void syncAlarmList() {
        sendCommand((e) ->e.onNext(mControlManager.setClocksSyncRequest()));
    }

    @Override
    void saveUserProfile(boolean gender, int age, int height, int weight) {
        SPWristbandConfigInfo.setGendar(App.getAppContext(), gender);
        SPWristbandConfigInfo.setAge(App.getAppContext(), age);
        SPWristbandConfigInfo.setHeight(App.getAppContext(), height);
        SPWristbandConfigInfo.setWeight(App.getAppContext(), weight);
        sendCommand((e) -> e.onNext(mControlManager.setUserProfile(gender, age, height, weight)));
    }

    @Override
    void saveStepTarget(int stepTarget) {
        sendCommand((e) -> e.onNext(mControlManager.setTargetStep(stepTarget)));
    }

    @Override
    void findBand() {
        sendCommand((e) ->e.onNext(mControlManager.enableImmediateAlert(true)));
    }

    @Override
    void setSedentaryReminder(boolean enable , int alarmCycle) {
        sendCommand((e) ->e.onNext(mControlManager.setLongSit(enable, alarmCycle, 0, 23,(byte) 255)));
    }

    @Override
    void setTurnOverWrist(boolean enable) {
        sendCommand(e -> e.onNext(mControlManager.setTurnOverWrist(enable)));
    }

    @Override
    void setLeftOrRightHand(byte mode) {
        sendCommand(e -> e.onNext(mControlManager.settingCmdLeftRightSetting(mode)));
    }

    @Override
    void enableNotifyInfo(byte mode) {
        sendCommand(e -> e.onNext(mControlManager.setNotifyMode(mode)));
    }

    @Override
    void sendCallNotifyInfo(String notifyInfo) {
        sendCommand(e -> e.onNext(mControlManager.sendCallNotifyInfo(notifyInfo)));
    }

    @Override
    void setCallAcceptNotify() {
        sendCommand(e -> e.onNext(mControlManager.sendCallAcceptNotifyInfo()));
    }

    @Override
    void setCallRejectNotify() {
        sendCommand(e -> e.onNext(mControlManager.sendCallRejectNotifyInfo()));
    }

    @Override
    void sendOtherNotifyInfo(byte mode, String notifyInfo) {
        sendCommand(e -> e.onNext(mControlManager.sendOtherNotifyInfo(ApplicationLayer.OTHER_NOTIFY_INFO_QQ, notifyInfo)));
    }

    @Override
    void setDeviceName(String deviceName) {
        sendCommand(e -> e.onNext(mControlManager.setDeviceName(deviceName)));
    }

    @Override
    void setDataSync(boolean enable) {
        sendCommand(e -> e.onNext(ControlManager.getInstance().setDataSync(enable)));

    }

    @Override
    void getSleepData() {

    }

    @Override
    void disconnect() {
        mConnectManager.disconnect();
    }


    private void sendConnectCommand(ObservableOnSubscribe<Boolean> cmdObservable) {
        Observable.create(cmdObservable)
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(aBoolean -> mView.cmdResult(aBoolean), throwable -> mView.cmdError(throwable));
    }

    private void sendCommand(ObservableOnSubscribe<Boolean> cmdObservable) {
        if (!mConnectManager.isConnect()) {
            mView.deviceNotConnect();
            return;
        }
        Observable.create(cmdObservable)
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(aBoolean -> mView.cmdResult(aBoolean), throwable -> mView.cmdError(throwable));
    }
}
