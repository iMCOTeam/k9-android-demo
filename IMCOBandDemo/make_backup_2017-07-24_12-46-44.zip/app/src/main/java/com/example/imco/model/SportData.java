package com.example.imco.model;

import java.util.Date;

import io.realm.RealmObject;
import io.realm.annotations.PrimaryKey;

/**
 * Created by mai on 17-7-17.
 */

public class SportData extends RealmObject {
    @PrimaryKey
    public Long id;
    public int year;
    public int month;
    public int day;
    public int offset;
    public int mode;
    public int stepCount;
    public int activeTime;
    public int calory;
    public int distance;
    public Date date;
}
