package com.example.imco.model;

import android.bluetooth.BluetoothDevice;

public class BleDevicesBean {

	private BluetoothDevice device;
	private int rssi;

	public BleDevicesBean() {
	}

	public BleDevicesBean(BluetoothDevice device, int rssi) {
		setDevice(device);
		setRssi(rssi);
	}

	public int getRssi() {
		return rssi;
	}

	public void setRssi(int rssi) {
		this.rssi = rssi;
	}

	public BluetoothDevice getDevice() {
		return device;
	}

	public void setDevice(BluetoothDevice device) {
		this.device = device;
	}
}
