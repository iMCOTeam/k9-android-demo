package com.example.imco.mvp.main;

import android.content.Context;

import com.example.imco.mvp.BasePresenter;
import com.example.imco.mvp.BaseView;
import com.imco.protocollayer.applicationlayer.ApplicationLayerAlarmPacket;
import com.realsil.android.blehub.dfu.ImcoOtaCallback;
import com.realsil.android.blehub.dfu.RealsilDfu;

import java.util.ArrayList;

/**
 * Created by mai on 17-6-22.
 */

public interface MainContract {
    interface MainView extends BaseView {
        void getContentStatus(boolean contentStatus);

        void getCurrentStep(long step);

        void getCalorie(long calorie);

        void getDistance(long distance);

        void showHeartRate(int interval);

        void newOtaFileVersion(int newFwVersion);

        void setupAlarm(boolean result);

        void alarmList(ArrayList<ApplicationLayerAlarmPacket> alarmList);

        void cmdResult(boolean result);

        void cmdError(Throwable e);

        void firmwareVersion(String fv);

        void firmwarePath(String fp);

        void getFwVersionTip();

        void deviceNotConnect();

        void connecting(int statusCode);

        void connectError(int errorCode);
    }

    abstract class MainPresenter extends BasePresenter<MainView> {
        abstract void startSync();

        abstract void disconnect();

        abstract void connect();

        abstract void isConnected();

        abstract void unBind();

        abstract void startAutoConnect();

        abstract void stopAutoConnect();

        // heart rate
        abstract void readHeartRate();

        abstract void stopReadHeartRate();

        abstract void cycleMeasureHeartRate(boolean enable, int interval);

        // ota // TODO: 17-6-26 upload ota file from ftp when ftp service create
        abstract void initOtaProxy(Context context, ImcoOtaCallback listener);

        abstract boolean ota(RealsilDfu dfu, String firmwarePath);

        abstract void readBatteryLevel();

        abstract int getBatteryLevel();

        abstract void checkNewVersion(String vendor, String deviceType);

        abstract void loadOtaFileInfo(String path);

        abstract void getFwVersion();

        // alarm
        abstract void settingAlarm(int hour, int minute, byte daysFlag, int alarmId);

        abstract void closeAlarm();

        abstract void syncAlarmList();

        abstract void saveUserProfile(boolean gender, int age, int height, int weight);

        abstract void saveStepTarget(int stepTarget);

        abstract void findBand();

        abstract void setSedentaryReminder(boolean enable, int alarmCycle);

        abstract void setTurnOverWrist(boolean enable);

        //
        abstract void setLeftOrRightHand(byte mode);

        abstract void enableNotifyInfo(byte mode);

        abstract void sendCallNotifyInfo(String notifyInfo);

        abstract void setCallAcceptNotify();

        abstract void setCallRejectNotify();

        abstract void sendOtherNotifyInfo(byte mode, String notifyInfo);

        abstract void setDeviceName(String deviceName);

        abstract void setDataSync(boolean enable);

        abstract void getSleepData();
    }
}
