package com.example.imco.mvp.main;

import android.app.FragmentManager;
import android.app.LoaderManager;
import android.content.CursorLoader;
import android.content.Intent;
import android.content.Loader;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Switch;
import android.widget.TextView;

import com.example.imco.model.R;
import com.example.imco.mvp.BaseActivity;
import com.example.imco.weight.AlarmInfoFragment;
import com.example.utils.DateUtils;
import com.example.utils.DialogUtils;
import com.imco.interactivelayer.manager.ControlManager;
import com.imco.protocollayer.applicationlayer.ApplicationLayer;
import com.imco.protocollayer.applicationlayer.ApplicationLayerAlarmPacket;
import com.realsil.android.blehub.dfu.RealsilDfu;
import com.realsil.android.blehub.dfu.ImcoOtaCallback;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

import static com.imco.protocollayer.applicationlayer.ApplicationLayer.CALL_NOTIFY_MODE_DISABLE_QQ;
import static com.imco.protocollayer.applicationlayer.ApplicationLayer.CALL_NOTIFY_MODE_ENABLE_QQ;
import static com.imco.protocollayer.applicationlayer.ApplicationLayer.CALL_NOTIFY_MODE_OFF;
import static com.imco.protocollayer.applicationlayer.ApplicationLayer.CALL_NOTIFY_MODE_ON;
import static com.imco.protocollayer.applicationlayer.ApplicationLayer.OTHER_NOTIFY_INFO_QQ;

/**
 * Created by mai on 17-6-21.
 */

public class MainActivity extends BaseActivity<MainPresenter> implements MainContract.MainView, LoaderManager.LoaderCallbacks<Cursor>
        , AlarmInfoFragment.OnSaveListener {
    public final static String BLUETOOTH_DEVICE = "bluetooth_device";
    public final static String TAG = "MainActivity";
    private static final int SELECT_FILE_REQ = 1;
    private boolean mReadHRing = true;
    private static final String EXTRA_URI = "uri";
    private boolean isInOta;
    private Uri mFileStreamUri;
    private byte mDayAlarms = ApplicationLayer.REPETITION_ALL;

    // mOtaProxy object
    private RealsilDfu mOtaProxy = null;
    private String mFilePath;

    @BindView(R.id.tvContentStatus)
    TextView tvContentStatus;

    @BindView(R.id.btn_start_sync)
    Button btnStartSync;

    @BindView(R.id.tv_step)
    TextView tvStepCount;

    @BindView(R.id.tv_calorie)
    TextView tvCalorie;

    @BindView(R.id.tv_distance)
    TextView tvDistance;

    @BindView(R.id.tv_heart_rate)
    TextView tvHeartRate;

    @BindView(R.id.tv_ota)
    TextView tvOtaVersion;

    @BindView(R.id.tv_alarm_time)
    TextView tvAlarmTime;

    @BindView(R.id.tv_alarm_date)
    TextView tvAlarmDate;

    @BindView(R.id.s_alarm)
    Switch sAlarm;

    @BindView(R.id.et_age)
    EditText etAge;

    @BindView(R.id.et_height)
    EditText etHeight;

    @BindView(R.id.et_weight)
    EditText etWeight;

    @BindView(R.id.btn_profile)
    Button btnProfile;

    @BindView(R.id.rg_gender)
    RadioGroup rgGender;

    @BindView(R.id.rb_man)
    RadioButton rbMan;

    @BindView(R.id.rb_woman)
    RadioButton rbWoman;

    @BindView(R.id.et_step_target)
    EditText etStepTarget;

    @BindView(R.id.et_alarm_cycle)
    EditText etAlarmCycle;

    @BindView(R.id.s_left_right_hand)
    Switch sLeftRightHand;

    @BindView(R.id.s_sedentary_reminder)
    Switch sSedentaryReminder;

    @BindView(R.id.s_enable_call_notify)
    Switch sEnableCallNotify;

    @BindView(R.id.s_other_info)
    Switch sOtherInfo;

    @BindView(R.id.et_call_notify_info)
    EditText etCallNotifyInfo;

    @BindView(R.id.et_other_info)
    EditText etOtherInfo;

    @BindView(R.id.et_device_name)
    EditText etDeviceName;

    @BindView(R.id.et_measure_cycle)
    EditText etMeasureCycle;

    @OnClick(R.id.btn_cycle_measure)
    public void cycleMeasure(View view) {
        if (etMeasureCycle.getText().toString().isEmpty()) {
            showToast(R.string.value_is_null);
            return;
        }
        mPresenter.cycleMeasureHeartRate(true, Integer.valueOf(etMeasureCycle.getText().toString()));
    }

    @BindView(R.id.s_turn_over_wrist)
    Switch sTurnOverWrist;
    @OnClick(R.id.btn_push_target)
    public void pushTarget(View view) {
        if (etStepTarget.getText().toString().isEmpty()) {
            showToast(R.string.value_is_null);
            return;
        }
        mPresenter.saveStepTarget(Integer.valueOf(etStepTarget.getText().toString()));
    }

    @OnClick(R.id.btn_profile)
    public void saveProfile(View view) {
        if (etAge.getText().toString().isEmpty() || etHeight.getText().toString().isEmpty() || etWeight.getText().toString().isEmpty()) {
            showToast(R.string.value_is_null);
            return;
        }

        mPresenter.saveUserProfile(rbMan.isChecked(), Integer.valueOf(etAge.getText().toString()),
                Integer.valueOf(etHeight.getText().toString()), Integer.valueOf(etWeight.getText().toString()));
    }

    @OnClick(R.id.tv_alarm_time)
    public void settingAlarm(View view) {
        String timeString[] = tvAlarmTime.getText().toString().split(":");
        int hour = Integer.valueOf(timeString[0]);
        int minute = Integer.valueOf(timeString[1]);
        final FragmentManager fm = getFragmentManager();
        // start le scan, with no filter
        final AlarmInfoFragment dialog = AlarmInfoFragment.getInstance(this);

        Bundle bundle = new Bundle();
        bundle.putInt(AlarmInfoFragment.EXTRAS_VALUE_POSITION, 0);
        bundle.putInt(AlarmInfoFragment.EXTRAS_DEFAULT_HOUR, hour);
        bundle.putInt(AlarmInfoFragment.EXTRAS_DEFAULT_MINUTE, minute);
        bundle.putByte(AlarmInfoFragment.EXTRAS_DEFAULT_DAY_FLAG, mDayAlarms);
        dialog.setArguments(bundle);

        dialog.show(fm, "alarm_fragment");
    }

    @OnClick(R.id.btn_heart_rate)
    public void onClick(View view) {
        if (mReadHRing) {
            mReadHRing = false;
            mPresenter.readHeartRate();
        } else {
            mReadHRing = true;
            mPresenter.stopReadHeartRate();
        }
    }

    @OnClick(R.id.btn_un_bond)
    public void onUnBindClick(View view) {
        mPresenter.unBind();
        finish();
    }

    @OnClick(R.id.btn_select_file)
    public void btnSelectFile(View view) {
        final Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        // intent.setType("file/*.bin");
        intent.setType("file/*");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        if (intent.resolveActivity(getPackageManager()) != null) {
            // file browser has been found on the device
            startActivityForResult(intent, SELECT_FILE_REQ);
        } else {
            showToast(R.string.file_browser_not_found);
        }
    }

    @OnClick(R.id.btn_start_sync)
    public void onSyncClick(View view) {
        mPresenter.startSync();
    }

    @OnClick(R.id.btn_ota)
    public void clickUpdateFirmware() {
        int batteryLevel = mPresenter.getBatteryLevel();
        if (batteryLevel >= 0
                && batteryLevel < 40) {
            showToast(String.format(getString(R.string.dfu_battery_not_enough), batteryLevel));
            Log.e(TAG, "the battery level is too low. batteryLevel: " + batteryLevel);
            return;
        }
        mPresenter.ota(mOtaProxy, mFilePath);
    }

    @OnClick(R.id.btn_read_battery)
    public void readBattery() {
        mPresenter.readBatteryLevel();
    }

    @OnClick(R.id.btn_find_band)
    public void findBand() {
        mPresenter.findBand();
    }

    @OnClick(R.id.btn_accept_notify)
    public void acceptNotify() {
        mPresenter.setCallAcceptNotify();
    }

    @OnClick(R.id.btn_reject_notify)
    public void rejectNotify() {
        mPresenter.setCallRejectNotify();
    }

    @OnClick(R.id.btn_other_info)
    public void sendOtherInfo() {
        if (etOtherInfo.getText().toString().isEmpty()) {
            showToast(R.string.value_is_null);
            return;
        }
        mPresenter.sendOtherNotifyInfo(OTHER_NOTIFY_INFO_QQ, etOtherInfo.getText().toString());
    }

    @OnClick(R.id.btn_send_call_notify)
    public void sendCallNotify() {
        if (etCallNotifyInfo.getText().toString().isEmpty()) {
            showToast(R.string.value_is_null);
            return;
        }
        mPresenter.sendCallNotifyInfo(etCallNotifyInfo.getText().toString());
    }

    @OnClick(R.id.btn_confirm)
    public void confirmDeviceName(View view){
        if (etDeviceName.getText().toString().isEmpty()) {
            showToast(R.string.value_is_null);
            return;
        }
        mPresenter.setDeviceName(etDeviceName.getText().toString());
    }

    @OnClick(R.id.btn_select_from_net)
    public void getFWFromNet() {
        mPresenter.checkNewVersion("iMCO", "k9");
    }

    @OnClick(R.id.btn_get_fw_version)
    public void getFWVersion() {
        mPresenter.getFwVersion();
    }

    @OnClick(R.id.btn_connect)
    public void connect() {
        mPresenter.connect();
    }

    @OnClick(R.id.btn_disconnect)
    public void disconnect() {
        mPresenter.disconnect();
    }

    @OnClick(R.id.btn_start_auto_connect)
    public void startAutoConnect() {
        mPresenter.startAutoConnect();
    }

    @OnClick(R.id.btn_stop_auto_connect)
    public void stopAutoConnect() {
        mPresenter.stopAutoConnect();
    }

    @BindView(R.id.btn_battery)
    Button btnBattery;

    @OnClick(R.id.btn_battery)
    public void battery() {
        btnBattery.setText(""+mPresenter.getBatteryLevel());
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_layout);
        ButterKnife.bind(this);
        // get the Realsil RealsilDfu proxy
        mPresenter.initOtaProxy(this, cb);
        mPresenter.isConnected();
        sAlarm.setOnCheckedChangeListener((buttonView, isChecked) -> {
            showToast("" + sAlarm.isChecked());
            String timeString[] = tvAlarmTime.getText().toString().split(":");
            int hour = Integer.valueOf(timeString[0]);
            int minute = Integer.valueOf(timeString[1]);
            if (isChecked) {
                mPresenter.settingAlarm(hour, minute, mDayAlarms, 0);
            } else {
                mPresenter.closeAlarm();
            }
        });

        sSedentaryReminder.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (etAlarmCycle.getText().toString().isEmpty()) {
                showToast(R.string.value_is_null);
                return;
            }
            mPresenter.setSedentaryReminder(isChecked, Integer.valueOf(etAlarmCycle.getText().toString()));
        });

        sTurnOverWrist.setOnCheckedChangeListener((buttonView, isChecked) -> mPresenter.setTurnOverWrist(isChecked));

        sLeftRightHand.setOnCheckedChangeListener((buttonView, isChecked) -> mPresenter.setLeftOrRightHand((byte) (isChecked ? 1 : 2)));

        sEnableCallNotify.setOnCheckedChangeListener((buttonView, isChecked) ->
                mPresenter.enableNotifyInfo(isChecked ? CALL_NOTIFY_MODE_ON : CALL_NOTIFY_MODE_OFF));

        sOtherInfo.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (etOtherInfo.getText().toString().isEmpty()) {
                showToast(R.string.value_is_null);
                return;
            }
//            SPWristbandConfigInfo.setNotifyQQFlag(App.getAppContext(), isChecked);
            mPresenter.enableNotifyInfo((byte) (isChecked ? CALL_NOTIFY_MODE_ENABLE_QQ : CALL_NOTIFY_MODE_DISABLE_QQ));
        });

    }

    @Override
    public void getContentStatus(boolean contentStatus) {
        tvContentStatus.setText("" + contentStatus);
    }

    @Override
    public void getCurrentStep(long step) {
        tvStepCount.setText("" + step);
    }

    @Override
    public void getCalorie(long calorie) {
        tvCalorie.setText("" + calorie);
    }

    @Override
    public void getDistance(long distance) {
        tvDistance.setText("" + distance);
    }

    @Override
    public void showHeartRate(int interval) {
        tvHeartRate.setText("" + interval);
        mReadHRing = false;
    }

    @Override
    public void newOtaFileVersion(int newFwVersion) {
        if (newFwVersion == -1) {
            showToast(R.string.dfu_file_status_invalid);
        }
        tvOtaVersion.setText(String.valueOf(newFwVersion));
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mPresenter.disconnect();
        if (mOtaProxy != null) {
            mOtaProxy.finalize();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
            case SELECT_FILE_REQ:
                if (resultCode != RESULT_OK)
                    return;

                // clear previous data
                mFilePath = null;
                mFileStreamUri = null;

                // and read new one
                final Uri uri = data.getData();
                /*
                 * The URI returned from application may be in 'file' or 'content' schema.
                 * 'File' schema allows us to create a File object and read details from if directly.
                 * Data from 'Content' schema must be read by Content Provider. To do that we are using a Loader.
                 */
                if (uri.getScheme().equals("file")) {
                    // the direct path to the file has been returned
                    String path = uri.getPath();
                    mFilePath = path;
                    // load the file
                    mPresenter.loadOtaFileInfo(path);

                } else if (uri.getScheme().equals("content")) {
                    // an Uri has been returned
                    mFileStreamUri = uri;
                    // if application returned Uri for streaming, let's us it. Does it works?
                    // FIXME both Uris works with Google Drive app. Why both? What's the difference? How about other apps like DropBox?
                    final Bundle extras = data.getExtras();
                    if (extras != null && extras.containsKey(Intent.EXTRA_STREAM))
                        mFileStreamUri = extras.getParcelable(Intent.EXTRA_STREAM);

                    // file name and size must be obtained from Content Provider
                    Bundle bundle = new Bundle();
                    bundle.putParcelable(EXTRA_URI, uri);
                    getLoaderManager().restartLoader(0, bundle, this);
                }
                break;
        }
    }

    @Override
    public Loader<Cursor> onCreateLoader(int id, Bundle args) {
        Uri uri = args.getParcelable(EXTRA_URI);
        String[] projection = new String[]{MediaStore.MediaColumns.DISPLAY_NAME, MediaStore.MediaColumns.SIZE, MediaStore.MediaColumns.DATA};
        return new CursorLoader(this, uri, projection, null, null, null);
    }

    @Override
    public void onLoadFinished(final Loader<Cursor> loader, final Cursor data) {
        if (data.moveToNext()) {
            String fileName = data.getString(0 /* DISPLAY_NAME */);
            int fileSize = data.getInt(1 /* SIZE */);
            String filePath = data.getString(2 /* DATA */);
            // load the file
            mFilePath = filePath;
            // load the file
            mPresenter.loadOtaFileInfo(filePath);
        }
    }

    @Override
    public void onLoaderReset(Loader<Cursor> loader) {
        tvOtaVersion.setText(null);
        mFilePath = null;
        mFileStreamUri = null;
    }

    ImcoOtaCallback cb = new ImcoOtaCallback() {
        public void onServiceConnectionStateChange(boolean status, RealsilDfu d) {
            Log.e(TAG, "onServiceConnectionStateChange status: " + status);
            if (status == true) {
                showToast("DFU Service connected");
                mOtaProxy = d;
            } else {
                showToast("DFU Service disconnected");
                mOtaProxy = null;
            }
        }

        public void onError(int e) {
            Log.e(TAG, "onError: " + e);
            showToast(getString(R.string.dfu_status_error_msg, e));
            ControlManager.getInstance().close();
        }

        public void onSucess(int s) {
            Log.e(TAG, "onSucess: " + s);
            showToast(R.string.dfu_status_completed_msg);
            ControlManager.getInstance().close();
        }

        public void onProcessStateChanged(int state) {
            Log.e(TAG, "onProcessStateChanged: " + state);
            showToast("onProcessStateChanged: " + state);
        }

        public void onProgressChanged(int progress) {
            Log.e(TAG, "onProgressChanged: " + progress);
            showToast("onProgressChanged: " + progress);
        }
    };

    @Override
    public void onAlarmInfoSaved(int position, int hour, int minute, byte dayFlag) {
        String hourStr = String.valueOf(hour).length() == 1
                ? "0" + String.valueOf(hour)
                : String.valueOf(hour);
        String minuteStr = String.valueOf(minute).length() == 1
                ? "0" + String.valueOf(minute)
                : String.valueOf(minute);
        final String timeStr = hourStr + ":" + minuteStr;

        if (position == 0) {
            tvAlarmTime.setText(timeStr);
            mDayAlarms = dayFlag;
            tvAlarmDate.setText(DateUtils.getDayFlagString(mDayAlarms));
            if (sAlarm.isChecked()) {
                mPresenter.settingAlarm(hour, minute, dayFlag, position);
            } else {
                sAlarm.setChecked(true);
            }
        } else if (position == 1) {
            // TODO: 17-6-26 The second alarm
        } // more alarm , Up to 8
    }

    @Override
    public void setupAlarm(boolean result) {
        if (result) {
            showToast(R.string.settings_mydevice_setting_alarm_success);
        } else {
            showToast(R.string.settings_mydevice_setting_alarm_failed);
        }
    }

    @Override
    public void alarmList(ArrayList<ApplicationLayerAlarmPacket> alarmList) {
        // TODO: 17-6-26 show alarm list in ui
    }

    @Override
    public void cmdResult(boolean result) {
        showToast("Send command : "+ result);
    }

    @Override
    public void cmdError(Throwable e) {
        showToast("Send command failed !");
    }

    @Override
    public void firmwareVersion(String fv) {
        tvOtaVersion.setText(fv);
    }

    @Override
    public void firmwarePath(String fp) {
        mFilePath = fp;
    }

    @Override
    public void getFwVersionTip() {
        showToast(R.string.get_fw_version_tips);
    }

    @Override
    public void deviceNotConnect() {
        showToast(R.string.device_not_connect);
    }

    @Override
    public void connecting(int statusCode) {
        switch (statusCode) {
            case -1 :
                break;
            case ControlManager.STATE_WRIST_LOGING:
                DialogUtils.getInstance().cancelProgressBar();
                DialogUtils.getInstance().showProgressBar(R.string.login);
                break;
            case ControlManager.STATE_WRIST_BONDING:
                DialogUtils.getInstance().cancelProgressBar();
                DialogUtils.getInstance().showProgressBar(R.string.bonding);
                break;
            case ControlManager.STATE_WRIST_LOGIN:
                DialogUtils.getInstance().cancelProgressBar();
                break;
        }
    }

    @Override
    public void connectError(int errorCode) {
        DialogUtils.getInstance().cancelProgressBar();

        switch (errorCode) {
            case ControlManager.ERROR_CODE_NO_LOGIN_RESPONSE_COME:
                showToast(R.string.error_code_no_login_response_come);
                break;
            case ControlManager.ERROR_CODE_BOND_ERROR:
                showToast(R.string.connect_band_already_bond);
                break;
            case ControlManager.ERROR_CODE_COMMAND_SEND_ERROR:
                showToast(R.string.error_code_command_send_error);
                break;
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        mPresenter.setDataSync(true);
    }

    @Override
    protected void onPause() {
        super.onPause();
        mPresenter.setDataSync(false);
    }
}
