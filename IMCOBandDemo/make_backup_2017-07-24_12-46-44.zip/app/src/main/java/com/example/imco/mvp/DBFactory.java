package com.example.imco.mvp;

import com.example.imco.model.SportData;

import io.realm.Realm;
import io.realm.RealmResults;

/**
 * Created by mai on 17-7-17.
 */

public class DBFactory {

    public static void loadSportDataByDate(int y, int m, int d) {
        Realm realm = Realm.getDefaultInstance();
    }

//    public static void get

    /**
     * load special sport data by date
     *
     * @return all the sport data in table
     */
    public Long getSportDataIdByDateAndOffset(int y, int m, int d, int offset) {
        Realm realm = Realm.getDefaultInstance();
        RealmResults<SportData> all = realm.where(SportData.class)
                .equalTo("year", y)
                .equalTo("month", m)
                .equalTo("day", d)
                .equalTo("offset", offset).findAll();
        if (all.size() > 0) {
            return all.get(0).id;
        } else {
            return -1l;
        } 


//        private int year;
//        private int month;
//        private int day;
//        private int offset;
    }

    public static void saveSportData(SportData sportData) {
        Realm realm = Realm.getDefaultInstance();
        realm.beginTransaction();
        realm.copyToRealmOrUpdate(sportData);
        realm.commitTransaction();
    }
}
