package com.example.imco.mvp;

/**
 * Created by mai on 17-6-22.
 */

public interface BaseView {
}
