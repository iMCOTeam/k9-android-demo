package com.imco.interactivelayer.manager;

/**
 * Created by mai on 17-7-18.
 */

public interface SendCommandCallback {
    /**
     * Whether the command was sent successfully
     *
     * @param status true is successfully, false is failed
     */
    public abstract void onCommandSend(boolean status);

    /**
     * Whether the bracelet is connected when the command is sent
     *
     */
    public abstract void onDisConnected();

    /**
     * Error when sending command
     *
     * @param error error code
     */
    public abstract void onError(Throwable error) ;
}
