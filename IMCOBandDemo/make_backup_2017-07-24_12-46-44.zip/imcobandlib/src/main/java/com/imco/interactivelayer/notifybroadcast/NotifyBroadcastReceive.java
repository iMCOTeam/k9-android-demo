package com.imco.interactivelayer.notifybroadcast;

import android.content.BroadcastReceiver;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.telephony.PhoneStateListener;
import android.telephony.SmsMessage;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.util.Log;

import com.imco.interactivelayer.manager.ConnectManager;
import com.imco.interactivelayer.manager.ControlManager;

import java.text.SimpleDateFormat;
import java.util.Date;

public class NotifyBroadcastReceive extends BroadcastReceiver {
    // Log
    private final static String TAG = "NotifyBroadcastReceive";
    private final static boolean D = true;

    public final static int BROADCAST_CALL_WAIT = 0;
    public final static int BROADCAST_CALL_ACC = 1;
    public final static int BROADCAST_CALL_REJ = 2;
    public final static int BROADCAST_SMS = 3;
    public final static int BROADCAST_QQ = 4;
    public final static int BROADCAST_WECHAT = 5;

    public final static int MAXIMUM_LENGTH_MSG = 20;

    public final static String ACTION_BROADCAST_CALL = "android.intent.action.PHONE_STATE";
    public final static String ACTION_BROADCAST_SMS = "android.provider.Telephony.SMS_RECEIVED";
    public final static String ACTION_BROADCAST_QQ_AND_WECHAT = NotificationReceive.BROADCAST_TYPE;
    //public final static String ACTION_BROADCAST_WECHAT = "android.intent.action.PHONE_STATE";

    OnBroadcastListener mCallback;
    public NotifyBroadcastReceive(OnBroadcastListener callback) {
        if(D) Log.d(TAG, "init");
        mCallback = callback;
    }
    @Override
    public void onReceive(Context context, Intent intent) {
        if(D) Log.d(TAG, "onReceive, action: " + intent.getAction());
        // Need check current link again
        if (D) Log.d(TAG, "onReceive() - isConnect() : " + ConnectManager.getInstance().isConnect()
                             + "onReceive() - ControlManager.getInstance().mWristState : " + ControlManager.getInstance().mWristState
                             + "onReceive() - isInLogin() : " + ConnectManager.getInstance().isInLogin());
        if(!(ConnectManager.getInstance().isConnect()
                && ControlManager.getInstance().isReady()
                && !ConnectManager.getInstance().isInLogin())) {
            if(D) Log.e(TAG, "Receive broadcast with state error, do nothing!");
            return;
        }
        if(intent.getAction().equals(ACTION_BROADCAST_CALL)){
            doReceivePhone(context, intent);
        } else if(intent.getAction().equals(ACTION_BROADCAST_SMS)) {
            doReceiveSms(context, intent);

        } else if(intent.getAction().equals(ACTION_BROADCAST_QQ_AND_WECHAT)) {
            /*
            final int type = intent.getIntExtra(NotificationReceive.EXTRA_TYPE, 0);
            if(D) Log.i(TAG, "Receive NotificationReceive type : " + type);
            if(mCallback != null) {
                mCallback.onBroadcastCome(type, "");
            }
            */
            doReceiveQQorWechat(context, intent);
        }
    }
    public void close() {
        mCallback = null;
    }

    public void  doReceiveQQorWechat(Context context, Intent intent) {
        final int type = intent.getIntExtra(NotificationReceive.EXTRA_TYPE, 0);
        if(D) Log.i(TAG, "Receive NotificationReceive type : " + type);
        String title = intent.getStringExtra(NotificationReceive.EXTRA_TITLE);
        if(D) Log.i(TAG, "Receive NotificationReceive title : " + title);
        CharSequence text = intent.getCharSequenceExtra(NotificationReceive.EXTRA_TEXT);
        if(D) Log.i(TAG, "Receive NotificationReceive text : " + text);
        CharSequence subText = intent.getCharSequenceExtra(NotificationReceive.EXTRA_SUBTEXT);
        if(D) Log.i(TAG, "Receive NotificationReceive subText : " + subText);

        String showDataTmp = "";
        String showData;
        if (title != null) {
            if (text != null) {
                showDataTmp = title + ":" + text.toString();
            } else {
                showDataTmp = title + ":";
            }
        }

        if (showDataTmp.length() > MAXIMUM_LENGTH_MSG) {
            showData = showDataTmp.substring(0, MAXIMUM_LENGTH_MSG-1) + "...";
        } else {
            showData = showDataTmp;
        }
        if(D) Log.i(TAG, "qq or wechat showData : " + showData);

        if(mCallback != null) {
            mCallback.onBroadcastCome(type, showData);
        }
    }

    public void doReceiveSms(Context context, Intent intent) {
        SmsMessage msg = null;
        String showData = "";
        Bundle bundle = intent.getExtras();
        if (bundle != null) {
            Object[] pdusObj = (Object[]) bundle.get("pdus");
            for (Object p : pdusObj) {
                msg = SmsMessage.createFromPdu((byte[]) p);

                String msgTxt = msg.getMessageBody();//得到消息的内容

                Date date = new Date(msg.getTimestampMillis());//时间
                SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                String receiveTime = format.format(date);

                String senderNumber = msg.getOriginatingAddress();

                showData = senderNumber + ": " + msgTxt;

                if (msgTxt.equals("Testing!")) {
                    System.out.println("success!");
                } else {
                    Log.i(TAG, "Send number11：" + senderNumber + ", msg: " + msgTxt + ", time: " + receiveTime);
                    break;
                }
            }
        }

        Log.i(TAG, "SmCallback: " + (mCallback == null));
        if(mCallback != null) {
            mCallback.onBroadcastCome(BROADCAST_SMS, showData);
        }
    }
    /**
     * operate the receive phone broadcast.
     * @param context
     * @param intent
     */
    public void doReceivePhone(Context context, Intent intent) {
        String phoneNumber = intent.getStringExtra(
                TelephonyManager.EXTRA_INCOMING_NUMBER);
        String showData = getContactNameByPhoneNumber(context, phoneNumber);
        if (TextUtils.isEmpty(showData)) {
            showData = phoneNumber;
        }
        TelephonyManager telephony =
                (TelephonyManager)context.getSystemService(Context.TELEPHONY_SERVICE);
        int state = telephony.getCallState();
        switch(state){
            case TelephonyManager.CALL_STATE_RINGING:
                if(D) Log.i(TAG, "[Listener]wait:"+phoneNumber + ", Name: " + showData);
                if(mCallback != null) {
                    mCallback.onBroadcastCome(BROADCAST_CALL_WAIT, showData);
                }
                break;
            case TelephonyManager.CALL_STATE_IDLE:
                if(D) Log.i(TAG, "[Listener]close:"+phoneNumber + ", Name: " + showData);
                if(mCallback != null) {
                    mCallback.onBroadcastCome(BROADCAST_CALL_REJ, showData);
                }
                break;
            case TelephonyManager.CALL_STATE_OFFHOOK:
                if(D) Log.i(TAG, "[Broadcast]in call:"+phoneNumber + ", Name: " + showData);
                if(mCallback != null) {
                    mCallback.onBroadcastCome(BROADCAST_CALL_ACC, showData);
                }
                break;
        }
    }

    /**
     * 电话状态监听.
     * @author stephen
     *
     */
    class OnePhoneStateListener extends PhoneStateListener {
        @Override
        public void onCallStateChanged(int state, String incomingNumber) {
            Log.i(TAG, "[Listener] phone number: "+incomingNumber);
            switch(state){
                case TelephonyManager.CALL_STATE_RINGING:
                    Log.i(TAG, "[Listener]wait:"+incomingNumber);
                    //mCallback.onBroadcastCome(BROADCAST_CALL);
                    break;
                case TelephonyManager.CALL_STATE_IDLE:
                    Log.i(TAG, "[Listener]close:"+incomingNumber);
                    break;
                case TelephonyManager.CALL_STATE_OFFHOOK:
                    Log.i(TAG, "[Listener]in call:"+incomingNumber);
                    break;
            }
            super.onCallStateChanged(state, incomingNumber);
        }
    }
    /**
     * Interface required to be implemented by activity
     */
    public static interface OnBroadcastListener {
        /**
         * Fired when Call/Message/QQ/Wechat notify come
         *
         * @param type      notify type
         */
        public void onBroadcastCome(int type, String data);
    }


    /*
     * 根据电话号码取得联系人姓名
     */
    public static String getContactNameByPhoneNumber(Context context, String address) {
        String[] projection = { ContactsContract.PhoneLookup.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER };

        // 将自己添加到 msPeers 中
        Cursor cursor = context.getContentResolver().query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                projection, // Which columns to return.
                ContactsContract.CommonDataKinds.Phone.NUMBER + " = '"
                        + address + "'", // WHERE clause.
                null, // WHERE clause value substitution
                null); // Sort order.

        if (cursor == null) {
            Log.d(TAG, "getPeople null");
            return null;
        }
        for (int i = 0; i < cursor.getCount(); i++) {
            cursor.moveToPosition(i);

            // 取得联系人名字
            int nameFieldColumnIndex = cursor
                    .getColumnIndex(ContactsContract.PhoneLookup.DISPLAY_NAME);
            String name = cursor.getString(nameFieldColumnIndex);
            return name;
        }
        return null;
    }

    /**
     * 获取所有联系人内容
     * @param context
     * @return
     */
    public static String getContacts(Context context) {
        StringBuilder sb = new StringBuilder();

        ContentResolver cr = context.getContentResolver();
        Cursor cursor = cr.query(ContactsContract.Contacts.CONTENT_URI, null,
                null, null, null);

        if (cursor.moveToFirst()) {
            do {
                String contactId = cursor.getString(cursor
                        .getColumnIndex(ContactsContract.Contacts._ID));
                String name = cursor
                        .getString(cursor
                                .getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME));
                //第一条不用换行
                if (sb.length() == 0) {
                    sb.append(name);
                } else {
                    sb.append("\n" + name);
                }

                Cursor phones = cr.query(
                        ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                        null, ContactsContract.CommonDataKinds.Phone.CONTACT_ID
                                + " = " + contactId, null, null);
                while (phones.moveToNext()) {
                    String phoneNumber = phones
                            .getString(phones
                                    .getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
                    // 添加Phone的信息
                    sb.append("\t").append(phoneNumber);

                }
                phones.close();

            } while (cursor.moveToNext());
        }
        cursor.close();
        return sb.toString();
    }


}
