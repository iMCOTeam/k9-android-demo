package com.imco.interactivelayer.manager;

import android.content.Context;
import android.os.Build;
import android.text.TextUtils;
import android.util.Log;
import android.webkit.MimeTypeMap;

import com.imco.interactive.MyNotificationManager;
import com.imco.protocollayer.applicationlayer.ApplicationLayerAlarmPacket;
import com.imco.protocollayer.applicationlayer.ApplicationLayerAlarmsPacket;
import com.imco.protocollayer.gattlayer.GlobalGatt;
import com.realsil.android.blehub.dfu.BinInputStream;
import com.realsil.android.blehub.dfu.ImcoOtaCallback;
import com.realsil.android.blehub.dfu.RealsilDfu;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

import io.reactivex.Observable;
import io.reactivex.ObservableEmitter;
import io.reactivex.ObservableOnSubscribe;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;

/**
 * Created by mai on 17-7-18.
 */

public class CommandManager {

    private static final String TAG = "CommandManager";

    public static void init(Context context) {
        ControlManager.initial(context);
        ConnectManager.init(context);
        MyNotificationManager.init(context);
    }

    public static void registerCallback(ControlManagerCallback callback) {
        ControlManager.getInstance().registerCallback(callback);
    }

    public static boolean isCallbackRegisted(ControlManagerCallback callback) {
        return ControlManager.getInstance().isCallbackRegisted(callback);
    }

    public static void unRegisterCallback(ControlManagerCallback callback) {
        ControlManager.getInstance().unRegisterCallback(callback);
    }

    private static void sendCommand(ObservableOnSubscribe<Boolean> cmdObservable, final SendCommandCallback callback) {
        if (!ConnectManager.getInstance().isConnect()) {
            if (null != callback) {
                callback.onDisConnected();
            }
            return;
        }
        Observable.create(cmdObservable)
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Consumer<Boolean>() {
                    @Override
                    public void accept(Boolean aBoolean) throws Exception {
                        if (null != callback) {
                            callback.onCommandSend(aBoolean);
                        }
                    }
                }, new Consumer<Throwable>() {
                    @Override
                    public void accept(Throwable throwable) throws Exception {
                        if (null != callback)
                            callback.onError(throwable);
                    }
                });
    }


    /**
     * set the name
     *
     * @param name the name
     */
    public static void setDeviceName(final String name, SendCommandCallback callback) {
        sendCommand(new ObservableOnSubscribe<Boolean>() {
            @Override
            public void subscribe(ObservableEmitter<Boolean> e) throws Exception {
                e.onNext(ControlManager.getInstance().setDeviceName(name));
            }
        }, callback);
    }

    /**
     * Get the name
     */
    public static void getDeviceName(SendCommandCallback callback) {
        sendCommand(new ObservableOnSubscribe<Boolean>() {
            @Override
            public void subscribe(ObservableEmitter<Boolean> e) throws Exception {
                e.onNext(ControlManager.getInstance().getDeviceName());
            }
        }, callback);
    }

    /**
     * Use to sync the notify mode
     *
     * @param mode 0x01 enable call notify; 0x02 disable call notify
     * @return the operate result
     */
    public static void setNotifyMode(final byte mode, SendCommandCallback callback) {
        sendCommand(new ObservableOnSubscribe<Boolean>() {
            @Override
            public void subscribe(ObservableEmitter<Boolean> e) throws Exception {
                e.onNext(ControlManager.getInstance().setNotifyMode(mode));
            }
        }, callback);
    }

    /**
     * Use to request current notify mode
     *
     * @return the operate result
     */
    public static void sendNotifyModeRequest(SendCommandCallback callback) {
        sendCommand(new ObservableOnSubscribe<Boolean>() {
            @Override
            public void subscribe(ObservableEmitter<Boolean> e) throws Exception {
                e.onNext(ControlManager.getInstance().sendNotifyModeRequest());
            }
        }, callback);
    }

    /**
     * Use to start/stop data sync.
     *
     * @param enable start or stop data sync.
     * @return the operate result
     */
    public static void setDataSync(final boolean enable, SendCommandCallback callback) {
        sendCommand(new ObservableOnSubscribe<Boolean>() {
            @Override
            public void subscribe(ObservableEmitter<Boolean> e) throws Exception {
                e.onNext(ControlManager.getInstance().setDataSync(enable));
            }
        }, callback);
    }

    /**
     * Use to send data request.
     *
     * @return the operate result
     */
    public static void sendDataRequest(SendCommandCallback callback) {
        sendCommand(new ObservableOnSubscribe<Boolean>() {
            @Override
            public void subscribe(ObservableEmitter<Boolean> e) throws Exception {
                e.onNext(ControlManager.getInstance().sendDataRequest());
            }
        }, callback);
    }

    /**
     * Use to enable/disable the long sit set
     *
     * @return the operate result
     */
    public static void setLongSit(final boolean enable, SendCommandCallback callback) {
        sendCommand(new ObservableOnSubscribe<Boolean>() {
            @Override
            public void subscribe(ObservableEmitter<Boolean> e) throws Exception {
                e.onNext(ControlManager.getInstance().setLongSit(enable));
            }
        }, callback);
    }

    /**
     * Use to enable/disable the long sit set, and setup alarmTime
     *
     * @param alarmTime: alarm cycle
     * @param daysFlag   : 由底 bit 位到高 bit位,分别代表从周一到周日的重复设置。Bit 位为 1 是表示重复,
     *                   为 0 时表示不重复。所有的 bit 位都为 0时,表示只当天有效。
     * @return the operate result
     */
    public static void setLongSit(final boolean enable, final int alarmTime, final int startTime, final int endTime, final byte daysFlag, SendCommandCallback callback) {
        sendCommand(new ObservableOnSubscribe<Boolean>() {
            @Override
            public void subscribe(ObservableEmitter<Boolean> e) throws Exception {
                e.onNext(ControlManager.getInstance().setLongSit(enable, alarmTime, startTime, endTime, daysFlag));
            }
        }, callback);
    }

    /**
     * Use to enable/disable the continue hrp set
     *
     * @return the operate result
     */
    public static void setContinueHrp(final boolean enable, final int interval, SendCommandCallback callback) {
        sendCommand(new ObservableOnSubscribe<Boolean>() {
            @Override
            public void subscribe(ObservableEmitter<Boolean> e) throws Exception {
                e.onNext(ControlManager.getInstance().setContinueHrp(enable, interval));
            }
        }, callback);
    }

    /**
     * Use to enable/disable the continue hrp set
     *
     * @return the operate result
     */
    public static void setContinueHrp(final boolean enable, SendCommandCallback callback) {
        sendCommand(new ObservableOnSubscribe<Boolean>() {
            @Override
            public void subscribe(ObservableEmitter<Boolean> e) throws Exception {
                e.onNext(ControlManager.getInstance().setContinueHrp(enable));
            }
        }, callback);
    }


    public static void sendContinueHrpParamRequest(SendCommandCallback callback) {
        sendCommand(new ObservableOnSubscribe<Boolean>() {
            @Override
            public void subscribe(ObservableEmitter<Boolean> e) throws Exception {
                e.onNext(ControlManager.getInstance().sendContinueHrpParamRequest());
            }
        }, callback);
    }

    /**
     * Use to enable/disable the turn over wrist
     *
     * @return the operate result
     */
    public static void setTurnOverWrist(final boolean enable, SendCommandCallback callback) {
        sendCommand(new ObservableOnSubscribe<Boolean>() {
            @Override
            public void subscribe(ObservableEmitter<Boolean> e) throws Exception {
                e.onNext(ControlManager.getInstance().setTurnOverWrist(enable));
            }
        }, callback);
    }

    /**
     * Use to sync the long sit set
     *
     * @return the operate result
     */
    public static void setLongSit(final byte enable, final int threshold, final int notify, final int start, final int stop, final byte dayflags, SendCommandCallback callback) {
        sendCommand(new ObservableOnSubscribe<Boolean>() {
            @Override
            public void subscribe(ObservableEmitter<Boolean> e) throws Exception {
                e.onNext(ControlManager.getInstance().setLongSit(enable, threshold, notify, start, stop, dayflags));
            }
        }, callback);
    }


    /**
     * Use to request current long sit set
     *
     * @return the operate result
     */
    public static void sendLongSitRequest(SendCommandCallback callback) {
        sendCommand(new ObservableOnSubscribe<Boolean>() {
            @Override
            public void subscribe(ObservableEmitter<Boolean> e) throws Exception {
                e.onNext(ControlManager.getInstance().sendLongSitRequest());
            }
        }, callback);
    }

    /**
     * Use to request current long sit set
     *
     * @return the operate result
     */
    public static void sendTurnOverWristRequest(SendCommandCallback callback) {
        sendCommand(new ObservableOnSubscribe<Boolean>() {
            @Override
            public void subscribe(ObservableEmitter<Boolean> e) throws Exception {
                e.onNext(ControlManager.getInstance().sendTurnOverWristRequest());
            }
        }, callback);
    }

    /**
     * Use to sync the user profile, use local info
     *
     * @return the operate result
     */
    public static void setUserProfile(SendCommandCallback callback) {
        sendCommand(new ObservableOnSubscribe<Boolean>() {
            @Override
            public void subscribe(ObservableEmitter<Boolean> e) throws Exception {
                e.onNext(ControlManager.getInstance().setUserProfile());
            }
        }, callback);
    }

    /**
     * Use to sync the user profile
     *
     * @return the operate result
     */
    public static void setUserProfile(final boolean sex, final int age, final int height, final int weight, SendCommandCallback callback) {
        sendCommand(new ObservableOnSubscribe<Boolean>() {
            @Override
            public void subscribe(ObservableEmitter<Boolean> e) throws Exception {
                e.onNext(ControlManager.getInstance().setUserProfile(sex, age, height, weight));
            }
        }, callback);
    }

    /**
     * Use to sync the target step, user local info
     *
     * @return the operate result
     */
    public static void setTargetStep(SendCommandCallback callback) {
        sendCommand(new ObservableOnSubscribe<Boolean>() {
            @Override
            public void subscribe(ObservableEmitter<Boolean> e) throws Exception {
                e.onNext(ControlManager.getInstance().setTargetStep());
            }
        }, callback);
    }

    /**
     * Use to sync the target step
     *
     * @return the operate result
     */
    public static void setTargetStep(final long step, SendCommandCallback callback) {
        sendCommand(new ObservableOnSubscribe<Boolean>() {
            @Override
            public void subscribe(ObservableEmitter<Boolean> e) throws Exception {
                e.onNext(ControlManager.getInstance().setTargetStep(step));
            }
        }, callback);
    }

    /**
     * Use to set the phone os
     *
     * @return the operate result
     */
    public static void setPhoneOS(SendCommandCallback callback) {
        sendCommand(new ObservableOnSubscribe<Boolean>() {
            @Override
            public void subscribe(ObservableEmitter<Boolean> e) throws Exception {
                e.onNext(ControlManager.getInstance().setPhoneOS());
            }
        }, callback);
    }

    /**
     * Use to set the clocks
     *
     * @return the operate result
     */
    public static void setClocks(final ApplicationLayerAlarmsPacket alarms, SendCommandCallback callback) {
        sendCommand(new ObservableOnSubscribe<Boolean>() {
            @Override
            public void subscribe(ObservableEmitter<Boolean> e) throws Exception {
                e.onNext(ControlManager.getInstance().setClocks(alarms));
            }
        }, callback);
    }

    /**
     * Use to set the clock
     *
     * @return the operate result
     */
    public static void setClock(final ApplicationLayerAlarmPacket alarm, SendCommandCallback callback) {
        sendCommand(new ObservableOnSubscribe<Boolean>() {
            @Override
            public void subscribe(ObservableEmitter<Boolean> e) throws Exception {
                e.onNext(ControlManager.getInstance().setClock(alarm));
            }
        }, callback);
    }

    /**
     * Use to sync the clock
     *
     * @return the operate result
     */
    public static void setClocksSyncRequest(SendCommandCallback callback) {
        sendCommand(new ObservableOnSubscribe<Boolean>() {
            @Override
            public void subscribe(ObservableEmitter<Boolean> e) throws Exception {
                e.onNext(ControlManager.getInstance().setClocksSyncRequest());
            }
        }, callback);
    }

    /**
     * Use to sync the time
     *
     * @return the operate result
     */
    public static void setTimeSync(SendCommandCallback callback) {
        sendCommand(new ObservableOnSubscribe<Boolean>() {
            @Override
            public void subscribe(ObservableEmitter<Boolean> e) throws Exception {
                e.onNext(ControlManager.getInstance().setTimeSync());
            }
        }, callback);

    }

    /**
     * Use to send the call notify info
     *
     * @return the operate result
     */
    public static void sendCallNotifyInfo(SendCommandCallback callback) {
        sendCommand(new ObservableOnSubscribe<Boolean>() {
            @Override
            public void subscribe(ObservableEmitter<Boolean> e) throws Exception {
                e.onNext(ControlManager.getInstance().sendCallNotifyInfo());
            }
        }, callback);
    }

    public static void sendCallNotifyInfo(final String show, SendCommandCallback callback) {
        sendCommand(new ObservableOnSubscribe<Boolean>() {
            @Override
            public void subscribe(ObservableEmitter<Boolean> e) throws Exception {
                e.onNext(ControlManager.getInstance().sendCallNotifyInfo(show));
            }
        }, callback);
    }

    /**
     * Use to send the call accept notify info
     *
     * @return the operate result
     */
    public static void sendCallAcceptNotifyInfo(SendCommandCallback callback) {
        sendCommand(new ObservableOnSubscribe<Boolean>() {
            @Override
            public void subscribe(ObservableEmitter<Boolean> e) throws Exception {
                e.onNext(ControlManager.getInstance().sendCallAcceptNotifyInfo());
            }
        }, callback);
    }

    /**
     * Use to send the call reject notify info
     *
     * @return the operate result
     */
    public static void sendCallRejectNotifyInfo(SendCommandCallback callback) {
        sendCommand(new ObservableOnSubscribe<Boolean>() {
            @Override
            public void subscribe(ObservableEmitter<Boolean> e) throws Exception {
                e.onNext(ControlManager.getInstance().sendCallRejectNotifyInfo());
            }
        }, callback);
    }

    /**
     * Use to send the other notify info
     *
     * @return the operate result
     */
    public static void sendOtherNotifyInfo(final byte info, SendCommandCallback callback) {
        sendCommand(new ObservableOnSubscribe<Boolean>() {
            @Override
            public void subscribe(ObservableEmitter<Boolean> e) throws Exception {
                e.onNext(ControlManager.getInstance().sendOtherNotifyInfo(info));
            }
        }, callback);
    }

    public static void sendOtherNotifyInfo(final byte info, final String show, SendCommandCallback callback) {
        sendCommand(new ObservableOnSubscribe<Boolean>() {
            @Override
            public void subscribe(ObservableEmitter<Boolean> e) throws Exception {
                e.onNext(ControlManager.getInstance().sendOtherNotifyInfo(info, show));
            }
        }, callback);
    }

    /**
     * Use to send enable fac test mode
     *
     * @return the operate result
     */
    public static void sendEnableFacTest(SendCommandCallback callback) {
        sendCommand(new ObservableOnSubscribe<Boolean>() {
            @Override
            public void subscribe(ObservableEmitter<Boolean> e) throws Exception {
                e.onNext(ControlManager.getInstance().sendEnableFacTest());
            }
        }, callback);
    }

    /**
     * Use to send disable fac test mode
     *
     * @return the operate result
     */
    public static void sendDisableFacTest(SendCommandCallback callback) {
        sendCommand(new ObservableOnSubscribe<Boolean>() {
            @Override
            public void subscribe(ObservableEmitter<Boolean> e) throws Exception {
                e.onNext(ControlManager.getInstance().sendDisableFacTest());
            }
        }, callback);
    }

    /**
     * Use to send enable led
     *
     * @param led the led want to enable
     * @return the operate result
     */
    public static void sendEnableFacLed(final byte led, SendCommandCallback callback) {
        sendCommand(new ObservableOnSubscribe<Boolean>() {
            @Override
            public void subscribe(ObservableEmitter<Boolean> e) throws Exception {
                e.onNext(ControlManager.getInstance().sendEnableFacLed(led));
            }
        }, callback);
    }

    /**
     * Use to send enable vibrate
     *
     * @return the operate result
     */
    public static void sendEnableFacVibrate(SendCommandCallback callback) {
        sendCommand(new ObservableOnSubscribe<Boolean>() {
            @Override
            public void subscribe(ObservableEmitter<Boolean> e) throws Exception {
                e.onNext(ControlManager.getInstance().sendEnableFacVibrate());
            }
        }, callback);
    }

    /**
     * Use to send request sensor data
     *
     * @return the operate result
     */
    public static void sendEnableFacSensorDataRequest(SendCommandCallback callback) {
        sendCommand(new ObservableOnSubscribe<Boolean>() {
            @Override
            public void subscribe(ObservableEmitter<Boolean> e) throws Exception {
                e.onNext(ControlManager.getInstance().sendEnableFacSensorDataRequest());
            }
        }, callback);
    }

    /**
     * Use to send open log command
     *
     * @return the operate result
     */
    public static void sendLogEnableCommand(final byte[] keyArray, SendCommandCallback callback) {
        sendCommand(new ObservableOnSubscribe<Boolean>() {
            @Override
            public void subscribe(ObservableEmitter<Boolean> e) throws Exception {
                e.onNext(ControlManager.getInstance().sendLogEnableCommand(keyArray));
            }
        }, callback);
    }

    public static void sendLogEnableCommand(SendCommandCallback callback) {
        sendCommand(new ObservableOnSubscribe<Boolean>() {
            @Override
            public void subscribe(ObservableEmitter<Boolean> e) throws Exception {
                e.onNext(ControlManager.getInstance().sendLogEnableCommand());
            }
        }, callback);
    }

    /**
     * Use to send open log command
     *
     * @return the operate result
     */
    public static void sendLogCloseCommand(SendCommandCallback callback) {
        sendCommand(new ObservableOnSubscribe<Boolean>() {
            @Override
            public void subscribe(ObservableEmitter<Boolean> e) throws Exception {
                e.onNext(ControlManager.getInstance().sendLogCloseCommand());
            }
        }, callback);
    }

    /**
     * Use to send request log command
     *
     * @return the operate result
     */
    public static void sendLogRequestCommand(final byte key, SendCommandCallback callback) {
        sendCommand(new ObservableOnSubscribe<Boolean>() {
            @Override
            public void subscribe(ObservableEmitter<Boolean> e) throws Exception {
                e.onNext(ControlManager.getInstance().sendLogRequestCommand(key));
            }
        }, callback);
    }

    /**
     * Use to send sync today step command
     *
     * @return the operate result
     */
    public static void sendSyncTodayNearlyOffsetStepCommand(SendCommandCallback callback) {
        sendCommand(new ObservableOnSubscribe<Boolean>() {
            @Override
            public void subscribe(ObservableEmitter<Boolean> e) throws Exception {
                e.onNext(ControlManager.getInstance().sendSyncTodayNearlyOffsetStepCommand());
            }
        }, callback);
    }

    /**
     * Use to send remove bond command
     *
     * @return the operate result
     */
    public static void sendRemoveBondCommand(SendCommandCallback callback) {
        sendCommand(new ObservableOnSubscribe<Boolean>() {
            @Override
            public void subscribe(ObservableEmitter<Boolean> e) throws Exception {
                e.onNext(ControlManager.getInstance().sendRemoveBondCommand());
            }
        }, callback);
    }

    /**
     * Use to send camera control command
     *
     * @return the operate result
     */
    public static void sendCameraControlCommand(final boolean enable, SendCommandCallback callback) {
        sendCommand(new ObservableOnSubscribe<Boolean>() {
            @Override
            public void subscribe(ObservableEmitter<Boolean> e) throws Exception {
                e.onNext(ControlManager.getInstance().sendCameraControlCommand(enable));
            }
        }, callback);
    }

    /**
     * Set the remote left right hand. Command: 0x02, Key: 0x22.
     * <p>This is an asynchronous operation. Once the operation has been completed, the
     * reporting the result of the operation.
     *
     * @param mode the left right hand mode. 0x01 is left ; 0x02 is right;
     * @return the operation result
     */
    public static void settingCmdLeftRightSetting(final byte mode, SendCommandCallback callback) {
        sendCommand(new ObservableOnSubscribe<Boolean>() {
            @Override
            public void subscribe(ObservableEmitter<Boolean> e) throws Exception {
                e.onNext(ControlManager.getInstance().settingCmdLeftRightSetting(mode));
            }
        }, callback);
    }

    /**
     * Use to send sync today step command
     *
     * @return the operate result
     */
    public static void sendSyncTodayStepCommand(SendCommandCallback callback) {
        sendCommand(new ObservableOnSubscribe<Boolean>() {
            @Override
            public void subscribe(ObservableEmitter<Boolean> e) throws Exception {
                e.onNext(ControlManager.getInstance().sendSyncTodayStepCommand());
            }
        }, callback);
    }


    /**
     * Use to set the remote Link Loss Alert Level
     *
     * @param enable enable/disable Link Loss Alert
     */
    public static void enableLinkLossAlert(final boolean enable, SendCommandCallback callback) {
        sendCommand(new ObservableOnSubscribe<Boolean>() {
            @Override
            public void subscribe(ObservableEmitter<Boolean> e) throws Exception {
                e.onNext(ControlManager.getInstance().enableLinkLossAlert(enable));
            }
        }, callback);
    }

    /**
     * Use to read the remote Battery Level
     */
    public static void readBatteryLevel(SendCommandCallback callback) {
        sendCommand(new ObservableOnSubscribe<Boolean>() {
            @Override
            public void subscribe(ObservableEmitter<Boolean> e) throws Exception {
                e.onNext(ControlManager.getInstance().readBatteryLevel());
            }
        }, callback);
    }

    /**
     * Use to read the remote Hrp Level
     */
    public static void readHrpValue(SendCommandCallback callback) {
        sendCommand(new ObservableOnSubscribe<Boolean>() {
            @Override
            public void subscribe(ObservableEmitter<Boolean> e) throws Exception {
                e.onNext(ControlManager.getInstance().readHrpValue());
            }
        }, callback);
    }

    /**
     * Use to read the remote Hrp Level
     */
    public static void stopReadHrpValue(SendCommandCallback callback) {
        sendCommand(new ObservableOnSubscribe<Boolean>() {
            @Override
            public void subscribe(ObservableEmitter<Boolean> e) throws Exception {
                e.onNext(ControlManager.getInstance().stopReadHrpValue());
            }
        }, callback);
    }


    /**
     * Use to read the remote Link loss Level
     */
    public static void readLinkLossLevel(SendCommandCallback callback) {
        sendCommand(new ObservableOnSubscribe<Boolean>() {
            @Override
            public void subscribe(ObservableEmitter<Boolean> e) throws Exception {
                e.onNext(ControlManager.getInstance().readLinkLossLevel());
            }
        }, callback);
    }

    /**
     * Use to read the remote version info
     */
    public static void readDfuVersion(SendCommandCallback callback) {
        sendCommand(new ObservableOnSubscribe<Boolean>() {
            @Override
            public void subscribe(ObservableEmitter<Boolean> e) throws Exception {
                e.onNext(ControlManager.getInstance().readDfuVersion());
            }
        }, callback);
    }

    /**
     * Use to set the remote Immediate Alert Level
     *
     * @param enable enable/disable Immediate Alert
     */
    public static boolean enableImmediateAlert(boolean enable) {
        return ControlManager.getInstance().enableImmediateAlert(enable);
    }


    /**
     * Use to get the remote Battery Level
     */
    public static int getBatteryLevel() {
        return ControlManager.getInstance().getBatteryLevel();
    }

    /**
     * Use to check support extend flash
     */
    public static boolean checkSupportedExtendFlash() {
        return ControlManager.getInstance().checkSupportedExtendFlash();
    }

    /**
     * Check if there is a new firmware version
     *
     * @param vendor
     * @param deviceType
     */
    public static void checkNewFwVersion(String vendor, String deviceType) {
        ControlManager.getInstance().checkNewFwVersion(vendor, deviceType);
    }

    /**
     * Get current firmware version
     *
     * @return Current firmware version
     */
    public static int getCurrentFWVersion() {
        return ControlManager.getInstance().getCurrentFWVersion();
    }

    /**
     * Use to enable battery power notification
     */
    public static boolean enableBatteryNotification(boolean enable) {
        return ControlManager.getInstance().enableBatteryNotification(enable);
    }


    /**
     * Start OTA
     *
     * @param dfu          A RealsilDfu proxy object
     * @param firmwarePath Firmware path
     * @return true is success , false is failed
     */
    public static boolean startOTA(RealsilDfu dfu, String firmwarePath) {
        ControlManager mWristbandManager = ControlManager.getInstance();

        if (dfu == null || firmwarePath == null) {
            Log.e(TAG, "the realsil dfu didn't ready");
            return false;
        }

        // set the total speed for android 4.4, to escape the internal error
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {
            dfu.setSpeedControl(true, 1000);
        }
        // Use GlobalGatt do not need to disconnect, just unregister the callback
        GlobalGatt.getInstance().unRegisterAllCallback(mWristbandManager.getBluetoothAddress());
        /*
        // disconnect the gatt
        disconnect(mBtGatt);// be care here
        // wait a while for close gatt.
        try {
            Thread.sleep(100);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }*/
        if (mWristbandManager.checkSupportedExtendFlash()) {
            dfu.setWorkMode(RealsilDfu.OTA_MODE_EXTEND_FUNCTION);
        } else {
            dfu.setWorkMode(RealsilDfu.OTA_MODE_FULL_FUNCTION);
        }
        Log.e(TAG, "Start OTA, address is: " + mWristbandManager.getBluetoothAddress());
        if (dfu.start(mWristbandManager.getBluetoothAddress(), firmwarePath)) {
            Log.d(TAG, "true");
            return true;
        } else {
            Log.e(TAG, "something error in device info or the file, false");
            return false;
        }
    }

    /**
     * init OTA proxy
     *
     * @param context
     * @param listener
     */
    public static void initOtaProxy(Context context, ImcoOtaCallback listener) {
        RealsilDfu.getDfuProxy(context, listener);
    }

    /**
     * Get Ota file version
     * @param path ota file path
     * @return -1 is get fail , other is version
     */
    public static int getOtaFileVersion(String path) {
        // check the file path
        if (TextUtils.isEmpty(path) == true) {
            Log.e("TAG", "the file path string is null");
            return -1;
        }

        // check the file type
        if (MimeTypeMap.getFileExtensionFromUrl(path).equalsIgnoreCase("BIN") != true) {
            Log.e("TAG", "the file type is not right");
            return -1;
        }
        BinInputStream binInputStream;

        //get the new firmware version
        try {
            binInputStream = openInputStream(path);
        } catch (final IOException e) {
            Log.e(TAG, "An exception occurred while opening file", e);
            return -1;
        }

        short i = binInputStream.binFileVersion();
        // close the file
        if (binInputStream != null) {
            try {
                binInputStream.close();
                binInputStream = null;
            } catch (IOException e) {
                Log.e(TAG, "error in close file", e);
            }
        }
        return i;
    }

    /**
     * Opens the binary input stream from a BIN file. A Path to the BIN file is given.
     *
     * @param filePath the path to the BIN file
     * @return the binary input stream with BIN data
     * @throws IOException
     */
    private static BinInputStream openInputStream(final String filePath) throws IOException {
        final InputStream is = new FileInputStream(filePath);
        return new BinInputStream(is);
    }
}
