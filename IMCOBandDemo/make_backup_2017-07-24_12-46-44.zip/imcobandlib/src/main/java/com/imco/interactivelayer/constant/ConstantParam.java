package com.imco.interactivelayer.constant;

import android.os.Environment;


import java.io.File;


public class ConstantParam {
    // Bmob 接口的的APP Id
    public static final String BMOB_APPLICATION_ID = "f3e4d7568a05222d1ab882c58b350f13";
    //默认时间格式
    public static final String DEFAULT_TIME_FORMAT = "yyyy-MM-dd HH:mm:ss";

    public static final boolean WORK_TYPE_LOCAL = false;
    public static final boolean WORK_TYPE_INTERNET = true;
//    public static final boolean APP_WORK_TYPE = BuildConfig.APP_WORK_TYPE;
//
//    public static final String APP_BUILD_TYPE = BuildConfig.BUILD_TYPE;

    /**
     * 基本的缓存的路径
     */
    public static final String BASE_CACHR_DIR = getBaseCacheDir();
    /**
     * 缓存的文件目录的名字
     */
    private static final String CACHR_DIR_NAME = "RtkBand";

    /**
     * 包名
     */
    public static final String PACKAGE_NAME = "com.realsil.android.wristbanddemo";
    /**
     * 图片的缓存路径
     */
    public static final String IMAGE_SAVE_CACHE = getBaseCacheDir() + "saveImage/";

    //public static final String CAMERA_IMAGE_SAVE_CACHE = getCameraImageCacheDir();
    /**
     * 文件的缓存路径
     */
    public static final String FILE_SAVE_CACHE = getBaseCacheDir() + "saveFile/";
    /**
     * Log的缓存路径
     */
    public static final String LOG_SAVE_CACHE = getBaseCacheDir() + "saveLog/";
    /**
     * 第三方登陆默认密码，我们不使用默认提供的第三方登陆接口
     */
    public static final String DEFAULT_USER_PSW = "123456";
    /**
     * 第三方登陆默认密码，我们不使用默认提供的第三方登陆接口
     */
    public static final int DEFAULT_HISTORY_SYNC_MAX_SIZE = 5;// 5 days
    public static final String DEFAULT_DATE_FORMAT = "yyyyMMdd";

    public static final String DEFAULT_DETAIL_DATE_FORMAT = "yyyy-MM-dd HH:mm:ss";

    /**
     * 获取基本的缓存的路径
     *
     * @return
     */
    private static String getBaseCacheDir() {
        // TODO Auto-generated method stub
        if (Environment.getExternalStorageState().equals(android.os.Environment.MEDIA_MOUNTED)) {
            return Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + CACHR_DIR_NAME + "/";
            //return "sdcard" + "/" + CACHR_DIR_NAME + "/";
        } else {
            return "/data/data/" + PACKAGE_NAME + "/" + CACHR_DIR_NAME + "/";
        }
    }

    private static String getCameraImageCacheDir() {
        String imagePath = "sdcard/DCIM/";
        // init the cash path
        File file = new File(imagePath);
        if (file.exists()) {
            imagePath = "sdcard/DCIM/Camera/";
            if (file.exists()) {
                return imagePath;
            } else {
                imagePath = "sdcard/DCIM/100MEDIA/";
                if (file.exists()) {
                    return imagePath;
                } else {
                    imagePath = "sdcard/DCIM/100Andro/";
                    if (file.exists()) {
                        return imagePath;
                    }
                }
            }
        }

        return IMAGE_SAVE_CACHE;
    }

//    public static boolean isInDebugMode() {
//        Log.d("ConstantParam", "isInDebugMode, APP_BUILD_TYPE: " + APP_BUILD_TYPE);
//        if(APP_BUILD_TYPE.equals("debug")) {
//            return true;
//        }
//
//        return false;
//    }

    // 填写从短信SDK应用后台注册得到的APPKEY
    //此APPKEY仅供测试使用，且不定期失效，请到mob.com后台申请正式APPKEY
    public static String APPKEY = "1ad33f23ac15f";

    // 填写从短信SDK应用后台注册得到的APPSECRET
    public static String APPSECRET = "efec614ed6392028615b18e63b80ad20";
}
