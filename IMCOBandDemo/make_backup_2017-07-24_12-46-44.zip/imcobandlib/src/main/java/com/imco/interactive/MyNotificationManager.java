package com.imco.interactive;

import android.app.Notification;
import android.app.NotificationManager;
import android.content.Context;
import android.util.Log;


/**
 * Created by rain1_wen on 2016/10/18.
 */

public class MyNotificationManager {
    // Log
    private final static String TAG = "MyNotificationManager";
    private final static boolean D = true;
    // object
    private static MyNotificationManager mInstance;
    private static Context mContext;

    NotificationManager mNotificationManager;
    Notification mNotification;

    public static void init(Context context) {
        if(D) Log.d(TAG, "init()");
        mInstance = new MyNotificationManager();
        mContext = context;

        mInstance.mNotificationManager = (NotificationManager)mContext.getSystemService(Context.NOTIFICATION_SERVICE);
    }

    public static MyNotificationManager getInstance() {
        return mInstance;
    }

    private int counter;
    public void sendBatteryAlarmNotification(String string) {
      // todo 这里需要改回隐式跳转的方式
//        Intent intent = new Intent(mContext, MainActivity.class);
//        PendingIntent pi = PendingIntent.getActivity(mContext, 0, intent, 0);
//        mNotification = new Notification.Builder(mContext).setSmallIcon(R.mipmap.ic_launcher)
//                .setTicker(mContext.getString(R.string.notify_battery_alarm_ticker))
//                .setContentTitle(mContext.getString(R.string.notify_battery_alarm_title)).setContentText(string)
//                .setContentIntent(pi).setNumber(counter).getNotification();
//        mNotification.flags |= Notification.FLAG_AUTO_CANCEL;
//        mNotificationManager.notify(counter, mNotification);
//        counter++;
    }
}
