package com.imco.interactivelayer.manager;


import com.imco.protocollayer.applicationlayer.ApplicationLayerAlarmsPacket;
import com.imco.protocollayer.applicationlayer.ApplicationLayerFacSensorPacket;
import com.imco.protocollayer.applicationlayer.ApplicationLayerLogResponsePacket;
import com.imco.protocollayer.applicationlayer.ApplicationLayerSleepPacket;
import com.imco.protocollayer.applicationlayer.ApplicationLayerSportPacket;
import com.imco.protocollayer.applicationlayer.ApplicationLayerTodaySumSportPacket;

public class ControlManagerCallback {
	/**
	 * Callback indicating when gatt connected/disconnected to/from a remote device
	 *
	 * @param status status
	 */
	public void onConnectionStateChange(final boolean status) {
	}

	/**
	 * Callback indicating when login in to a wristband
	 *
	 * @param state state
	 */
	public void onLoginStateChange(final int state) {
	}

	/**
	 * Callback indicating something error
	 *
	 * @param error error code
	 */
	public void onError(final int error) {
	}

	/**
	 * Callback indicating a sport data receive.
	 *
	 */
	public void onSportDataReceiveIndication(ApplicationLayerSportPacket sportPacket) {
	}

	/**
	 * Callback a history sport data receive.
	 *	add by mai
	 */
	public void onSportDataCmdHistorySyncEnd(ApplicationLayerSportPacket packet) {}

	/**
	 * Callback a today sport data receive.
	 *	add by mai
	 */
	public void onSportDataCmdHistorySyncEnd(ApplicationLayerTodaySumSportPacket packet) {}
	/**
	 * Callback indicating a sleep data receive.
	 *
	 */
	public void onSleepDataReceiveIndication(ApplicationLayerSleepPacket sleep) {
	}

	/**
	 * Callback indicating a hrp data receive.
	 *
	 */
	public void onHrpDataReceiveIndication(int hrpValue) {
	}
	/**
	 * Callback indicating a device cancel hrp read.
	 *
	 */
	public void onDeviceCancelSingleHrpRead() {
	}
	/**
	 * Callback indicating a hrp continue param response.
	 *
	 */
	public void onHrpContinueParamRsp(boolean enable, int interval) {
	}
	/**
	 * Callback indicating alarm list data receive.
	 *
	 * @param data the receive alarm data packet
	 */
	public void onAlarmsDataReceive(ApplicationLayerAlarmsPacket data) {
	}

	/**
	 * Callback indicating notify mode setting receive.
	 *
	 * @param data the current notify mode
	 */
	public void onNotifyModeSettingReceive(byte data) {
	}

	/**
	 * Callback indicating notify mode setting receive.
	 *
	 * @param data the current long sit mode
	 */
	public void onLongSitSettingReceive(byte data) {
	}
	/**
	 * Callback indicate remote Turn Over Wrist setting.
	 *
	 * @param mode the long sit mode setting
	 */
	public void onTurnOverWristSettingReceive(final boolean mode) {
	}
	/**
	 * Callback indicate take a photo.
	 *
	 */
	public void onTakePhotoRsp() {
	}
	/**
	 * Callback indicating a fac sensor data receive.
	 *
	 * @param data the receive sensor data
	 */
	public void onFacSensorDataReceive(ApplicationLayerFacSensorPacket data) {
	}

	/**
	 * Callback indicating version read.
	 *
	 * @param appVersion   app Version value
	 * @param patchVersion patch Version value
	 */
	public void onVersionRead(int appVersion, int patchVersion) {
	}

	/**
	 *	No new version from network
	 * @param code
	 * code == 0，found the new firmware。
	 * code != 0，Did not find a new firmware, or the server side of the error,
	 * or parameters wrong, the specific reference to the following error code:
	 * CheckInNoNewVersion = 40200
	 * ErrNumCheckInFailed = 40201
	 * ErrNumCheckInWrongParameter = 40202
	 * ErrNumCheckInResourceNofound = 40203
	 */
	public void noNewVersion(int code, String message){}

	/**
	 * has new version from network
	 * @param description version description
	 * @param version version code
	 */
	public void hasNewVersion(String description, String version){}

	/**
	 * Download progress
	 * @param progressRate Download the progress of the firmware , Ranges from 0 to 100
	 */
	public void downloadProgress(int progressRate){}

	/**
	 * Download error
	 */
	public void downloadError(){}

	/**
	 * Download complete
	 * @param fwPath Firmware path
	 */
	public void downloadComplete(String fwPath){}

	/**
	 * Callback indicating name receive.
	 *
	 * @param data	 	the receive data
	 */
	public void onNameRead(final String data) {
	}
	/**
	 * Callback indicating battery read.
	 *
	 * @param value   battery level value
	 */
	public void onBatteryRead(int value) {
	}
	/**
	 * Callback indicating battery change.
	 *
	 * @param value   battery level value
	 */
	public void onBatteryChange(int value) {
	}
	/**
	 * Callback indicate log sync start.
	 * @param logLength the log total length
	 *
	 */
	public void onLogCmdStart(final long logLength) {
	}
	/**
	 * Callback indicate log sync end.
	 *
	 */
	public void onLogCmdEnd() {
	}
	/**
	 * Callback indicate log data.
	 * @param packet receive log data
	 *
	 */
	public void onLogCmdRsp(final ApplicationLayerLogResponsePacket packet) {
	}
}
