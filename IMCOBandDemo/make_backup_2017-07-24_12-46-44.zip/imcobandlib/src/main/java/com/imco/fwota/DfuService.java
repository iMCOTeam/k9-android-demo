package com.imco.fwota;

import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattService;
import android.os.Environment;
import android.util.Log;

import com.C;
import com.imco.protocollayer.gattlayer.GlobalGatt;
import com.imco.utils.LogUtils;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

import io.reactivex.Observer;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;
import io.reactivex.subjects.PublishSubject;
import okhttp3.ResponseBody;

public class DfuService {
    // LOG
    private static final boolean D = true;
    private static final String TAG = "DfuService";

    // Support Service UUID and Characteristic UUID
    private final static UUID OTA_SERVICE_UUID = UUID.fromString("0000d0ff-3c17-d293-8e48-14fe2e4da212");
    private final static UUID OTA_CHARACTERISTIC_UUID = UUID.fromString("0000ffd1-0000-1000-8000-00805f9b34fb");
    private final static UUID OTA_READ_PATCH_CHARACTERISTIC_UUID = UUID.fromString("0000ffd3-0000-1000-8000-00805f9b34fb");
    private final static UUID OTA_READ_APP_CHARACTERISTIC_UUID = UUID.fromString("0000ffd4-0000-1000-8000-00805f9b34fb");

    public final static UUID CLIENT_CHARACTERISTIC_CONFIG = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");


    public static final UUID DFU_SERVICE_UUID = UUID.fromString("00006287-3c17-d293-8e48-14fe2e4da212");
    // Add for extend OTA upload.
    private final static UUID OTA_EXTEND_FLASH_CHARACTERISTIC_UUID = UUID.fromString("00006587-3c17-d293-8e48-14fe2e4da212");

    // Support Service object and Characteristic object
    private BluetoothGattService mService;
    private BluetoothGattCharacteristic mAppCharac;
    private BluetoothGattCharacteristic mPatchCharac;

    private BluetoothGattService mDfuService;
    private BluetoothGattCharacteristic mExtendCharac;

    // Current Battery value
    private int mAppValue = -1;
    private int mPatchValue = -1;

    private GlobalGatt mGlobalGatt;

    private OnServiceListener mCallback;

    private String mBluetoothAddress;
    private String mFWPath;
    private String mFileName;

    public DfuService(String addr, OnServiceListener callback) {
        mCallback = callback;
        mBluetoothAddress = addr;

        mGlobalGatt = GlobalGatt.getInstance();
        initial();
    }

    public void close() {
        mGlobalGatt.unRegisterCallback(mBluetoothAddress, mGattCallback);
    }

    private void initial() {
        // register service discovery callback
        mGlobalGatt.registerCallback(mBluetoothAddress, mGattCallback);
    }

    public boolean setService(BluetoothGattService service) {
        if(service.getUuid().equals(OTA_SERVICE_UUID)) {
            mService = service;
            return true;
        }
        return false;
    }

    public List<BluetoothGattCharacteristic> getNotifyCharacteristic() {
        return null;
    }

    public boolean readInfo() {
        if(mAppCharac == null || mPatchCharac == null) {
            if(D) Log.e(TAG, "read Version info error with null charac");
            return false;
        }
        if(D) Log.d(TAG, "read Version info.");
        return readDeviceInfo(mAppCharac);
    }

    public String getServiceUUID() {
        return OTA_SERVICE_UUID.toString();
    }

    public String getServiceSimpleName() {
        return "Dfu";
    }

    private final BluetoothGattCallback mGattCallback = new BluetoothGattCallback() {

        @Override
        public void onServicesDiscovered(BluetoothGatt gatt, int status) {
            if (status == BluetoothGatt.GATT_SUCCESS) {
                mService = gatt.getService(OTA_SERVICE_UUID);
                if(mService == null) {
                    Log.e(TAG, "OTA service not found");
                    return;
                }else {
                    mPatchCharac = mService.getCharacteristic(OTA_READ_PATCH_CHARACTERISTIC_UUID);
                    if(mPatchCharac == null) {
                        if(D) Log.e(TAG, "OTA Patch characteristic not found");
                        return;
                    }else {
                        if(D) Log.d(TAG, "OTA Patch characteristic is found, mPatchCharac: " + mPatchCharac.getUuid());
                    }
                    mAppCharac = mService.getCharacteristic(OTA_READ_APP_CHARACTERISTIC_UUID);
                    if(mAppCharac == null) {
                        if(D) Log.e(TAG, "OTA App characteristic not found");
                        return;
                    }else {
                        if(D) Log.d(TAG, "OTA App characteristic is found, mAppCharac: " + mAppCharac.getUuid());
                    }
                }

                mDfuService = gatt.getService(DFU_SERVICE_UUID);
                if(mDfuService == null) {
                    if(D) Log.e(TAG, "Dfu Service not found");
                    return;
                }else {
                    if(D) Log.d(TAG, "Dfu Service is found, mDfuService: " + mDfuService.getUuid());
                    mExtendCharac = mDfuService.getCharacteristic(OTA_EXTEND_FLASH_CHARACTERISTIC_UUID);
                    if(mExtendCharac == null) {
                        if(D) Log.e(TAG, "Dfu extend characteristic not found");
                        return;
                    }else {
                        if(D) Log.d(TAG, "Dfu extend characteristic is found, mExtendCharac: " + mExtendCharac.getUuid());
                    }
                }
                //isConnected = true;
            } else {
                if(D) Log.e(TAG, "Discovery service error: " + status);
            }
        }

        @Override
        public void onCharacteristicRead(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, int status) {
            //if(D) Log.d(TAG, "onCharacteristicRead UUID is: " + characteristic.getUuid() + ", addr: " +mBluetoothAddress);
            //if(D) Log.d(TAG, "onCharacteristicRead data value:"+ Arrays.toString(characteristic.getValue()) + ", addr: " +mBluetoothAddress);
            byte[] data = characteristic.getValue();
            if (status == BluetoothGatt.GATT_SUCCESS){
                if(characteristic.getUuid().equals(OTA_READ_APP_CHARACTERISTIC_UUID)) {
                    if(D) Log.d(TAG, "data = " + Arrays.toString(characteristic.getValue()));
                    byte[] appVersionValue = characteristic.getValue();
                    ByteBuffer wrapped = ByteBuffer.wrap(appVersionValue);
                    wrapped.order(ByteOrder.LITTLE_ENDIAN);
                    mAppValue = wrapped.getShort(0);

                    //mTargetVersionView.setText(String.valueOf(oldFwVersion));
                    if(D) Log.d(TAG, "old firmware version: " + mAppValue + " .getValue=" + Arrays.toString(characteristic.getValue()));
                    if(mPatchCharac != null) {
                        readDeviceInfo(mPatchCharac);
                    }
                }else if(characteristic.getUuid().equals(OTA_READ_PATCH_CHARACTERISTIC_UUID)){
                    byte[] patchVersionValue = characteristic.getValue();
                    ByteBuffer wrapped = ByteBuffer.wrap(patchVersionValue);
                    wrapped.order(ByteOrder.LITTLE_ENDIAN);
                    mPatchValue = wrapped.getShort(0);
                    if(D) Log.d(TAG, "old patch version: " + mPatchValue + " .getValue=" + Arrays.toString(characteristic.getValue()));
                    //here can add read other characteristic
                    mCallback.onVersionRead(mAppValue, mPatchValue);
                }
            }

        }
    };

    public boolean checkSupportedExtendFlash() {
        return mExtendCharac != null;
    }

    private boolean readDeviceInfo(BluetoothGattCharacteristic characteristic) {
        if(D) Log.d(TAG, "read readDeviceinfo:" + characteristic.getUuid().toString());
        if(characteristic != null){
            return mGlobalGatt.readCharacteristic(mBluetoothAddress, characteristic);
        } else {
            if(D) Log.e(TAG, "readDeviceinfo Characteristic is null");
        }
        return false;
    }

    public int getAppValue() {
        return mAppValue;
    }
    public int getPatchValue() {
        return mPatchValue;
    }

    /**
     * Interface required to be implemented by activity
     */
    public static interface OnServiceListener {
        /**
         * Fired when value come.
         *
         * @param appVersion      app Version value
         * @param patchVersion      patch Version value
         *
         */
        public void onVersionRead(int appVersion, int patchVersion);

        /**
         *
         * @param code
         * code == 0，found the new firmware。
         * code != 0，Did not find a new firmware, or the server side of the error,
         * or parameters wrong, the specific reference to the following error code:
         * CheckInNoNewVersion = 40200
         * ErrNumCheckInFailed = 40201
         * ErrNumCheckInWrongParameter = 40202
         * ErrNumCheckInResourceNofound = 40203
         */
        void noNewVersion(int code, String message);
        
        void hasNewVersion(String description, String version);
        
        /**
         * Download progress
         * @param progressRate Download the progress of the firmware , Ranges from 0 to 100
         */
        void downloadProgress(int progressRate);

        /**
         * Download error
         */
        void netWorkError(Throwable e);

        /**
         * Download complete
         * @param fwPath Firmware path
         */
        void downloadComplete(String fwPath);
    }

    private PublishSubject<Integer> mDownloadProgress = PublishSubject.create();

    public void checkNewFWVersion(String vendor, String deviceType) {
        Log.d(TAG, "checkNewFWVersion");
        Api.getInstance().service
                .checkFw(new FwBean(vendor, deviceType, C.FW_TYPE_APP, mBluetoothAddress, ""+mAppValue))
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Consumer<FwResultBean>() {
                    @Override
                    public void accept(FwResultBean fwResultBean) throws Exception {
                        Log.d(TAG, "download");

                        download(fwResultBean);
                    }
                }, new Consumer<Throwable>() {
                    @Override
                    public void accept(Throwable throwable) throws Exception {
                        mCallback.netWorkError(throwable);
                        Log.e(TAG, "checkNewFWVersion>>>>>>>>>>>>"+throwable.getMessage());
                    }
                });
    }


    public void checkNewPatchVersion(String vendor, String deviceType) {
        Api.getInstance().service
                .checkFw(new FwBean(vendor, deviceType, C.FW_TYPE_PATCH, mBluetoothAddress, ""+mPatchValue))
                .subscribeOn(Schedulers.io())
                .subscribe(new Consumer<FwResultBean>() {
                    @Override
                    public void accept(FwResultBean fwResultBean) throws Exception {
                        download(fwResultBean);
                    }
                }, new Consumer<Throwable>() {
                    @Override
                    public void accept(Throwable throwable) throws Exception {
                        mCallback.netWorkError(throwable);
                        Log.e(TAG, ">>>>>>>>>>>>"+throwable.getMessage());
                    }
                });
    }


    private void download(FwResultBean fwResultBean) {
        if (fwResultBean.code == 0) {
            Log.d(TAG, "(fwResultBean.code == 0)1");

            mCallback.hasNewVersion(fwResultBean.payload.description, fwResultBean.payload.version);
            Log.d(TAG, "(fwResultBean.code == 0)2");

            mFWPath = Environment.getExternalStorageDirectory().getPath() + "/fw/";
            File file = new File(mFWPath);
            if (!file.exists()) {
                file.mkdir();
            }
            mFileName = fwResultBean.payload.resourceUrl.substring(fwResultBean.payload.resourceUrl.lastIndexOf("/") + 1);
            Log.d(TAG, "(fwResultBean.code == 0)" + mFileName);
            Api.getInstance().service
                    .downloadFile(fwResultBean.payload.resourceUrl)
                    .subscribeOn(Schedulers.io())
                    .observeOn(Schedulers.io())
                    .subscribe(new Consumer<ResponseBody>() {
                        @Override
                        public void accept(ResponseBody responseBody) throws Exception {
                            Log.d(TAG, "subscribe");
                            mDownloadProgress = PublishSubject.create();
                            mDownloadProgress.distinct()
                                    .observeOn(AndroidSchedulers.mainThread())
                                    .subscribe(new Observer<Integer>() {
                                        @Override
                                        public void onSubscribe(Disposable d) {
                                            LogUtils.d(TAG, "onSubscribe ");
                                        }

                                        @Override
                                        public void onNext(Integer value) {
                                            LogUtils.d(TAG, "downloadProgress " + value);
                                            mCallback.downloadProgress(value);
                                        }

                                        @Override
                                        public void onError(Throwable e) {
                                            LogUtils.d(TAG, "onError ");

                                            mCallback.netWorkError(e);
                                        }

                                        @Override
                                        public void onComplete() {
                                            LogUtils.d(TAG, "onComplete ");
                                            mCallback.downloadComplete(mFWPath + mFileName);
                                        }
                                    });


                            save(responseBody.byteStream(),responseBody.contentLength(), mFWPath + mFileName);
                        }
                    }, new Consumer<Throwable>() {
                        @Override
                        public void accept(Throwable throwable) throws Exception {
                            Log.e(TAG, throwable.getMessage());
                        }
                    });
        } else {
            mCallback.noNewVersion(fwResultBean.code, fwResultBean.errorStr);
        }
    }

    private void save(InputStream inputStream,long fileLength, String localPath) {
        File file = new File(localPath);
        if (!file.exists()) {
            try {
                file.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        FileOutputStream outputStream = null;
        Log.d(TAG, "save");

        try {
            outputStream = new FileOutputStream(file);
            byte[] bytes = new byte[1024];
            int len;
            long total = 0;
            while ((len = inputStream.read(bytes)) != -1) {
                total += len;
                LogUtils.d(TAG, "total += len ");
                if (fileLength > 0) {
                    LogUtils.d(TAG, "fileLength > 0 ");

                    int percentage = (int) (total * 100 / fileLength);
                    mDownloadProgress.onNext(percentage);
                }
                outputStream.write(bytes, 0, len);
            }
        } catch (Exception e) {
            mDownloadProgress.onError(e);
            Log.e(TAG, ">>>>>>>>>>"+e.getMessage());

            if (file.exists()) {
                file.delete();
            }
        } finally {
            try {
                if (inputStream != null) inputStream.close();
                if (outputStream != null) outputStream.close();
            } catch (Exception e) {
                Log.e(TAG, ">>>>>>>>>>"+e.getMessage());
                mDownloadProgress.onError(e);
                e.printStackTrace();
            }
            Log.d(TAG, "finally");
            mDownloadProgress.onComplete();
        }
    }
}
