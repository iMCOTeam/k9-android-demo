package com.imco.interactivelayer.manager;

/*
 * Copyright (C) 2013 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import android.app.Service;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Handler;
import android.os.Message;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.util.Log;

import com.imco.bandlib.R;
import com.imco.fwota.DfuService;
import com.imco.interactive.MyNotificationManager;
import com.imco.interactive.SPWristbandConfigInfo;
import com.imco.interactivelayer.notifybroadcast.NotificationReceive;
import com.imco.interactivelayer.notifybroadcast.NotifyBroadcastReceive;
import com.imco.interactivelayer.receiver.systemdatelisten.SystemDateChangeBroadcastReceive;
import com.imco.protocollayer.applicationlayer.ApplicationLayer;
import com.imco.protocollayer.applicationlayer.ApplicationLayerAlarmPacket;
import com.imco.protocollayer.applicationlayer.ApplicationLayerAlarmsPacket;
import com.imco.protocollayer.applicationlayer.ApplicationLayerCallback;
import com.imco.protocollayer.applicationlayer.ApplicationLayerFacSensorPacket;
import com.imco.protocollayer.applicationlayer.ApplicationLayerHrpItemPacket;
import com.imco.protocollayer.applicationlayer.ApplicationLayerHrpPacket;
import com.imco.protocollayer.applicationlayer.ApplicationLayerLogResponsePacket;
import com.imco.protocollayer.applicationlayer.ApplicationLayerSleepItemPacket;
import com.imco.protocollayer.applicationlayer.ApplicationLayerSleepPacket;
import com.imco.protocollayer.applicationlayer.ApplicationLayerSportItemPacket;
import com.imco.protocollayer.applicationlayer.ApplicationLayerSportPacket;
import com.imco.protocollayer.applicationlayer.ApplicationLayerTodaySportPacket;
import com.imco.protocollayer.applicationlayer.ApplicationLayerTodaySumSportPacket;
import com.imco.protocollayer.gattlayer.GlobalGatt;
import com.imco.protocollayer.service.BatteryService;
import com.imco.protocollayer.service.HrpService;
import com.imco.protocollayer.service.ImmediateAlertService;
import com.imco.protocollayer.service.LinkLossService;
import com.imco.utils.LogUtils;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Calendar;

import static com.imco.protocollayer.applicationlayer.ApplicationLayer.DEBUG_LOG_TYPE_MAX_CNT;
import static com.imco.protocollayer.applicationlayer.ApplicationLayer.LOGIN_RSP_SUCCESS;


public class ControlManager
        implements BatteryService.OnServiceListener, NotifyBroadcastReceive.OnBroadcastListener,
        LinkLossService.OnServiceListener, DfuService.OnServiceListener, HrpService.OnServiceListener {
    // Log
    private final static String TAG = "ControlManager";
    private final static boolean D = true;

    public static final String ACTION_SYNC_DATA_OK = "ACTION_SYNC_DATA_OK";

    private boolean isInSyncDataToService = false;

    private String mDeviceName;

    private String mDeviceAddress;

    // Application Layer Object
    private ApplicationLayer mApplicationLayer;

    private boolean isConnected = false;

    private static final String ENABLED_NOTIFICATION_LISTENERS = "enabled_notification_listeners";

    // Message
    public static final int MSG_STATE_CONNECTED = 0;
    public static final int MSG_STATE_DISCONNECTED = 1;
    public static final int MSG_WRIST_STATE_CHANGED = 2;
    public static final int MSG_RECEIVE_SPORT_INFO = 3;//characteristic read
    public static final int MSG_RECEIVE_HISTORY_SPORT_INFO = 0x3000;//characteristic read
    public static final int MSG_RECEIVE_SLEEP_INFO = 4;
    public static final int MSG_RECEIVE_HISTORY_SYNC_BEGIN = 5;
    public static final int MSG_RECEIVE_HISTORY_SYNC_END = 6;
    public static final int MSG_RECEIVE_ALARMS_INFO = 7;
    public static final int MSG_RECEIVE_NOTIFY_MODE_SETTING = 8;
    public static final int MSG_RECEIVE_LONG_SIT_SETTING = 9;
    public static final int MSG_RECEIVE_FAC_SENSOR_INFO = 10;
    public static final int MSG_RECEIVE_DFU_VERSION_INFO = 11;
    public static final int MSG_RECEIVE_DEVICE_NAME_INFO = 12;
    public static final int MSG_RECEIVE_BATTERY_INFO = 13;
    public static final int MSG_RECEIVE_BATTERY_CHANGE_INFO = 14;
    public static final int MSG_RECEIVE_HRP_INFO = 15;
    public static final int MSG_RECEIVE_TAKE_PHOTO_RSP = 16;
    public static final int MSG_RECEIVE_TURN_OVER_WRIST_SETTING = 17;
    public static final int MSG_RECEIVE_HRP_DEVICE_CANCEL_SINGLE_READ = 18;
    public static final int MSG_RECEIVE_HRP_CONTINUE_PARAM_RSP = 19;

    public static final int MSG_RECEIVE_LOG_START = 50;
    public static final int MSG_RECEIVE_LOG_END = 51;
    public static final int MSG_RECEIVE_LOG_RSP = 52;


    public static final int MSG_ERROR = 100;

    // Wristband state manager
    public int mWristState;
    public static final int STATE_WRIST_INITIAL = 0;
    public static final int STATE_WRIST_LOGING = 1;
    public static final int STATE_WRIST_BONDING = 2;
    public static final int STATE_WRIST_LOGIN = 3;
    public static final int STATE_WRIST_SYNC_DATA = 4;
    public static final int STATE_WRIST_SYNC_HISTORY_DATA = 5;
    public static final int STATE_WRIST_SYNC_LOG_DATA = 6;
    public static final int STATE_WRIST_ENTER_TEST_MODE = 7;

    private boolean mErrorStatus;
    public static final int ERROR_CODE_NO_LOGIN_RESPONSE_COME = 1;
    public static final int ERROR_CODE_BOND_ERROR = 2;
    public static final int ERROR_CODE_COMMAND_SEND_ERROR = 3;


    // Token Key
    private final byte[] TEST_TOKEN_KEY = {(byte) 0x01, (byte) 0x01, (byte) 0x01, (byte) 0x01,
            (byte) 0x01, (byte) 0x01, (byte) 0x01, (byte) 0x01, (byte) 0x01, (byte) 0x01,
            (byte) 0x01, (byte) 0x01, (byte) 0x01, (byte) 0x01, (byte) 0x01, (byte) 0x01,
            (byte) 0x01, (byte) 0x01, (byte) 0x01, (byte) 0x01, (byte) 0x01, (byte) 0x01,
            (byte) 0x01, (byte) 0x01, (byte) 0x01, (byte) 0x01, (byte) 0x01, (byte) 0x01,
            (byte) 0x01, (byte) 0x01, (byte) 0x01, (byte) 0x01, (byte) 0x01, (byte) 0x01,
            (byte) 0x01, (byte) 0x01};

    // Use to manager request and response transaction
    private final Object mRequestResponseLock = new Object();
    private final int MAX_REQUEST_RESPONSE_TRANSACTION_WAIT_TIME = 30000;

    private volatile boolean isResponseCome;
    private volatile boolean isNeedWaitForResponse;

    // Use to manager command send transaction
    private volatile boolean isInSendCommand;
    private volatile boolean isCommandSend;
    private volatile boolean isCommandSendOk;
    private final Object mCommandSendLock = new Object();
    private final int MAX_COMMAND_SEND_WAIT_TIME = 15000;

    // object
    private static ControlManager mInstance;
    private static Context mContext;

    private ArrayList<ControlManagerCallback> mCallbacks;


    private NotifyBroadcastReceive mNotifyBroadcastReceive;
    private SystemDateChangeBroadcastReceive mSystemDateChangeBroadcastReceive;

    private BatteryService mBatteryService;
    private ImmediateAlertService mImmediateAlertService;
    private LinkLossService mLinkLossService;
    private DfuService mDfuService;

    // MyHandler
    //MyHandler mHandler;

    static void initial(Context context) {
        if (D) Log.d(TAG, "init()");

        GlobalGatt.initial(context);
        GlobalGatt.getInstance().initialize();

        mInstance = new ControlManager();
        mContext = context;
        // green dao
//        mInstance.mGlobalGreenDAO = GlobalGreenDAO.getInstance();
        mInstance.isConnected = false;

        // init Wristband Application Layer and register the callback
        mInstance.mApplicationLayer = new ApplicationLayer(context, mInstance.mApplicationCallback);

        // Initial Callback list
        mInstance.mCallbacks = new ArrayList<>();

        // Initial State
        mInstance.mWristState = STATE_WRIST_INITIAL;

    }

    public static ControlManager getInstance() {
        return mInstance;
    }

    /**
     * close band connect, clear all callback
     */
    public void close() {
        if (D) Log.d(TAG, "close()");
        // be careful here!!!!
        isConnected = false;

        mCallbacks.clear();
        mApplicationLayer.close();
        // close all wait lock
        synchronized (mRequestResponseLock) {
            isResponseCome = false;
            isNeedWaitForResponse = false;
            mRequestResponseLock.notifyAll();
        }

        synchronized (mCommandSendLock) {
            isCommandSend = false;
            isCommandSendOk = false;
            isInSendCommand = false;
            mCommandSendLock.notifyAll();
        }
        // unregister call back.
        unregisterNotifyBroadcast();
        unregisterDateChangeBroadcast();

        updateWristState(STATE_WRIST_INITIAL);
    }

    boolean isConnect() {
        if (D) Log.d(TAG, "isConnected: " + isConnected);
        return isConnected;
    }

    public String getBluetoothAddress() {
        return mDeviceAddress;
    }

    public void setBluetoothAddress(String mDeviceAddress) {
        this.mDeviceAddress = mDeviceAddress;
    }

    public void registerCallback(ControlManagerCallback callback) {
        synchronized (mCallbacks) {
            if (!mCallbacks.contains(callback)) {
                mCallbacks.add(callback);
            }
        }
    }

    public boolean isCallbackRegisted(ControlManagerCallback callback) {
        boolean isCon = false;
        synchronized (mCallbacks) {
            isCon = mCallbacks.contains(callback);
        }
        return isCon;
    }

    public void unRegisterCallback(ControlManagerCallback callback) {
        synchronized (mCallbacks) {
            if (mCallbacks.contains(callback)) {
                mCallbacks.remove(callback);
            }
        }
    }



    /**
     * connect to the wristband.
     */
    boolean connect(String address, ControlManagerCallback callback) {
        if (D) Log.d(TAG, "connect to: " + address);
        // register callback
        //mCallbacks.add(callback);
        registerCallback(callback);
        //mCallback = callback;

        mDeviceAddress = address;
        //HandlerThread handlerThread = new HandlerThread("handler_thread");
        //handlerThread.start();
        //mHandler = new MyHandler(handlerThread.getLooper());
        // connect to the device
        boolean connect = mApplicationLayer.connect(address);

        // Add first init flag
        SPWristbandConfigInfo.setFirstInitialFlag(mContext, true);
        // close all.
        if (mBatteryService != null) {
            mBatteryService.close();
            if (mImmediateAlertService != null)
                mImmediateAlertService.close();
            if (mLinkLossService != null)
                mLinkLossService.close();
            if (mDfuService != null)
                mDfuService.close();
            if (mNotifyBroadcastReceive != null) {
                mNotifyBroadcastReceive.close();
            }
        }
        // Extend service
        mBatteryService = new BatteryService(mDeviceAddress, this);
        mImmediateAlertService = new ImmediateAlertService(mDeviceAddress);
        mLinkLossService = new LinkLossService(mDeviceAddress, this);
        mDfuService = new DfuService(mDeviceAddress, this);

        // Register Broadcast
//        registerNotifyBroadcast();
        registerDateChangeBroadcast();

        return connect;
//        if (isInAlarm) {
//            stopAlarm();
//        }
        // Alert
//        mVibrator = (Vibrator) mContext.getSystemService(mContext.VIBRATOR_SERVICE);
//        mMediaPlayer = new MediaPlayer();
        /*
        mMediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
			@Override
			public void onCompletion(MediaPlayer mp) {

			}
		});*/
    }

    /**
     * send disconnect band command
     *
     * @return
     */
    void disconnect() {
        mApplicationLayer.disconnect();
    }

    public void startLoginProcess(final String id) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                // update state
                updateWristState(STATE_WRIST_LOGING);
                /*
                if(ConstantParam.isInDebugMode()) {
					if(D) Log.i(TAG, "Need to send log enable command.");
					SendLogEnableCommand();
				}*/

                // Enable battery notification
                enableBatteryNotification(true);

                // Request to login
                if (!RequestLogin(id)) {
                    if (!mErrorStatus) {
                        // update state
                        updateWristState(STATE_WRIST_BONDING);
                        // Request to bond
                        if (RequestBond(id)) {
                            // do all the setting work.
                            setDataSync(false);
                            if (requestSetNeedInfo()) {
                                // update state
                                updateWristState(STATE_WRIST_LOGIN);
                            }
                        } else {

                            if (D)
                                Log.e(TAG, "Something error in bond. isResponseCome: " + isResponseCome);
                            // some thing error
                            if (isResponseCome) {
                                sendErrorMessage(ERROR_CODE_BOND_ERROR);
                            } else {
                                sendErrorMessage(ERROR_CODE_NO_LOGIN_RESPONSE_COME);
                            }
                        }
                    } else {
                        // some thing error
                        sendErrorMessage(ERROR_CODE_NO_LOGIN_RESPONSE_COME);
                        if (D) Log.e(TAG, "long time no login response, do disconnect");
                    }
                } else {
                    //if(syncNotifySetting()) {
                    if (mLoginResponseStatus == LOGIN_RSP_SUCCESS) {
                        // time sync
                        if (setTimeSync()) {
                            if (setPhoneOS()) {
                                if (setClocksSyncRequest()) {
                                    if (sendNotifyModeRequest()) {
                                        if (sendLongSitRequest()) {
                                            if (sendTurnOverWristRequest()) {
                                                if (sendContinueHrpParamRequest()) {
                                                    // update state
                                                    updateWristState(STATE_WRIST_LOGIN);
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    //}
                }
            }
        }).start();

    }

    private boolean syncNotifySetting() {
        // init error status
        mErrorStatus = false;
        isResponseCome = false;
        if (sendNotifyModeRequest()) {
            // wait for a while the remote response
            synchronized (mRequestResponseLock) {
                if (!isResponseCome) {
                    try {
                        // wait a while
                        if (D)
                            Log.d(TAG, "wait the notify setting response come, wait for: " + MAX_REQUEST_RESPONSE_TRANSACTION_WAIT_TIME + "ms");
                        mRequestResponseLock.wait(MAX_REQUEST_RESPONSE_TRANSACTION_WAIT_TIME);
                    } catch (InterruptedException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                }
            }

            if (!isResponseCome) {
                if (D) Log.e(TAG, "wait the notify setting response come failed");

                mErrorStatus = true;
                return false;
            }

            // init error status
            mErrorStatus = false;
            isResponseCome = false;
            if (sendLongSitRequest()) {
                // wait for a while the remote response
                synchronized (mRequestResponseLock) {
                    if (!isResponseCome) {
                        try {
                            // wait a while
                            if (D)
                                Log.d(TAG, "wait the long sit setting response come, wait for: " + MAX_REQUEST_RESPONSE_TRANSACTION_WAIT_TIME + "ms");
                            mRequestResponseLock.wait(MAX_REQUEST_RESPONSE_TRANSACTION_WAIT_TIME);
                        } catch (InterruptedException e) {
                            // TODO Auto-generated catch block
                            e.printStackTrace();
                        }
                    }
                }
                if (!isResponseCome) {
                    if (D) Log.e(TAG, "wait the long sit setting response come failed");
                    mErrorStatus = true;
                    return false;
                }
                return true;
            }
        }
        return false;
    }

    public boolean requestSendLongsitRequestSync() {
        // init error status
        mErrorStatus = false;
        isResponseCome = false;
        if (sendLongSitRequest()) {
            // wait for a while the remote response
            synchronized (mRequestResponseLock) {
                if (!isResponseCome) {
                    try {
                        // wait a while
                        if (D)
                            Log.d(TAG, "wait the long sit setting response come, wait for: " + MAX_REQUEST_RESPONSE_TRANSACTION_WAIT_TIME + "ms");
                        mRequestResponseLock.wait(MAX_REQUEST_RESPONSE_TRANSACTION_WAIT_TIME);
                    } catch (InterruptedException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                }
            }
            if (!isResponseCome) {
                if (D) Log.e(TAG, "wait the long sit setting response come failed");
                mErrorStatus = true;
                return false;
            }
            return true;
        }
        return false;
    }

    private boolean requestSetNeedInfo() {
        boolean enableCall = SPWristbandConfigInfo.getNotifyCallFlag(mContext);
        boolean enableMes = SPWristbandConfigInfo.getNotifyMessageFlag(mContext);
        boolean enableQQ = SPWristbandConfigInfo.getNotifyQQFlag(mContext);
        boolean enableWechat = SPWristbandConfigInfo.getNotifyWechatFlag(mContext);

        //ApplicationLayerSitPacket sit = new ApplicationLayerSitPacket((byte) 0x01, 6123, 57, 16, 17, (byte) (ApplicationLayer.REPETITION_SUN | ApplicationLayer.REPETITION_FRI));
        // set time sync
        if (setUserProfile()) {
            if (setTargetStep()) {
                if (setTimeSync()) {
                    if (setPhoneOS()) {
                        if (setClocksSyncRequest()) {
                            if (sendNotifyModeRequest()) {
                                if (sendLongSitRequest()) {
                                    if (sendTurnOverWristRequest()) {
                                        if (sendSyncTodayStepCommand()) {
                                            if (sendSyncTodayNearlyOffsetStepCommand()) {
                                                if (sendContinueHrpParamRequest()) {
                                                    //if (SetNotifyMode(enableCall ? ApplicationLayer.CALL_NOTIFY_MODE_ON : ApplicationLayer.CALL_NOTIFY_MODE_OFF)) {
                                                    //if (SetNotifyMode(enableMes ? ApplicationLayer.CALL_NOTIFY_MODE_ENABLE_MESSAGE : ApplicationLayer.CALL_NOTIFY_MODE_DISABLE_MESSAGE)) {
                                                    //if (SetNotifyMode(enableQQ ? ApplicationLayer.CALL_NOTIFY_MODE_ENABLE_QQ : ApplicationLayer.CALL_NOTIFY_MODE_DISABLE_QQ)) {
                                                    //if (SetNotifyMode(enableWechat ? ApplicationLayer.CALL_NOTIFY_MODE_ENABLE_WECHAT : ApplicationLayer.CALL_NOTIFY_MODE_DISABLE_WECHAT)) {
                                                    if (D) Log.e(TAG, "all set is ok!");
                                                    return true;
                                                    //}
                                                    //}
                                                    //}
                                                    //}
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        return false;
    }

    /**
     * set the name
     *
     * @param name the name
     */
    public boolean setDeviceName(String name) {
        if (D) Log.d(TAG, "setDeviceName, name: " + name);
        initialCommandSend();

        mApplicationLayer.setDeviceName(name);

        isInSendCommand = false;

        SPWristbandConfigInfo.setInfoKeyValue(mContext, getBluetoothAddress(), name);
        return waitCommandSend();
    }

    /**
     * Get the name
     */
    public boolean getDeviceName() {
        if (D) Log.d(TAG, "getDeviceName");
        initialCommandSend();

        mApplicationLayer.getDeviceName();

        return waitCommandSend();
    }

    /**
     * Use to sync the notify mode
     *
     * @param mode 0x01 enable call notify; 0x02 disable call notify
     * @return the operate result
     */
    public boolean setNotifyMode(byte mode) {
        if (D) Log.d(TAG, "SetNotifyMode, mode: " + mode);
        initialCommandSend();

        // Try to set notify mode
        mApplicationLayer.settingCmdCallNotifySetting(mode);

        return waitCommandSend();
    }

    /**
     * Use to request current notify mode
     *
     * @return the operate result
     */
    public boolean sendNotifyModeRequest() {
        if (D) Log.d(TAG, "sendNotifyModeRequest");
        initialCommandSend();
        // Need add this
        isNeedWaitForResponse = true;
        // Try to request notify mode
        mApplicationLayer.settingCmdRequestNotifySwitchSetting();

        return waitCommandSend();
    }

    /**
     * Use to start/stop data sync.
     *
     * @param enable start or stop data sync.
     * @return the operate result
     */
    public boolean setDataSync(boolean enable) {
        if (D) Log.d(TAG, "setDataSync(): " + enable);
        /*
        if(mWristState != STATE_WRIST_LOGIN && mWristState != STATE_WRIST_SYNC_DATA) {
            if(D) Log.e(TAG, "setDataSync failed, with error state: " + mWristState);
            return false;
        }
        */

        initialCommandSend();

        // Try to start/stop data sync
        if (enable) {
            mApplicationLayer.sportDataCmdSyncSetting(ApplicationLayer.SPORT_DATA_SYNC_MODE_ENABLE);
            //if(!waitCommandSend()) {
            //	return false;
            //}
            //initialCommandSend();
            //mApplicationLayer.sportDataCmdRequestData();

            //updateWristState(STATE_WRIST_SYNC_DATA);
        } else {
            mApplicationLayer.sportDataCmdSyncSetting(ApplicationLayer.SPORT_DATA_SYNC_MODE_DISABLE);

            //updateWristState(STATE_WRIST_LOGIN);
        }

        return waitCommandSend();
    }

    /**
     * Use to send data request.
     *
     * @return the operate result
     */
    public boolean sendDataRequest() {
        if (D) Log.d(TAG, "sendDataRequest()");
        if (mWristState != STATE_WRIST_LOGIN && mWristState != STATE_WRIST_SYNC_DATA) {
            if (D) Log.e(TAG, "StartDataSync failed, with error state: " + mWristState);
            return false;
        }

        initialCommandSend();

        isNeedWaitForResponse = true;
        mApplicationLayer.sportDataCmdRequestData();

        return waitCommandSend();
    }

    /**
     * Use to enable/disable the long sit set
     *
     * @return the operate result
     */
    public boolean setLongSit(boolean enable) {
        if (D) Log.d(TAG, "setLongSit(), enable: " + enable);
        initialCommandSend();
//        ApplicationLayerSitPacket sit;
        if (enable) {
            mApplicationLayer.settingCmdLongSitSetting(ApplicationLayer.LONG_SIT_CONTROL_ENABLE
                    , 0, SPWristbandConfigInfo.getLongSitAlarmTime(mContext), 0, 0, (byte) 0);
        } else {
            mApplicationLayer.settingCmdLongSitSetting(ApplicationLayer.LONG_SIT_CONTROL_DISABLE
                    , 0, 0, 0, 0, (byte) 0);
        }
        // Try to set long sit
        return waitCommandSend();
    }

    /**
     * Use to enable/disable the long sit set, and setup alarmTime
     *
     * @param alarmTime: alarm cycle
     * @param daysFlag   : 由底 bit 位到高 bit位,分别代表从周一到周日的重复设置。Bit 位为 1 是表示重复,
     *                   为 0 时表示不重复。所有的 bit 位都为 0时,表示只当天有效。
     * @return the operate result
     */
    public boolean setLongSit(boolean enable, int alarmTime, int startTime, int endTime, byte daysFlag) {
        if (D) Log.d(TAG, "setLongSit(), enable: " + enable);
        initialCommandSend();
        if (enable) {
            // Try to set long sit
            mApplicationLayer.settingCmdLongSitSetting(ApplicationLayer.LONG_SIT_CONTROL_ENABLE
                    , 0, alarmTime, 0, 0, daysFlag);
        } else {
            // Try to set long sit
            mApplicationLayer.settingCmdLongSitSetting(ApplicationLayer.LONG_SIT_CONTROL_DISABLE
                    , 0, 0, 0, 0, (byte) 0);

        }

        return waitCommandSend();
    }

    /**
     * Use to enable/disable the continue hrp set
     *
     * @return the operate result
     */
    public boolean setContinueHrp(boolean enable, int interval) {
        if (D) Log.d(TAG, "setContinueHrp(), enable: " + enable);
        initialCommandSend();

        // Try to set long sit
        mApplicationLayer.sportDataCmdHrpContinueSet(enable, interval);

        return waitCommandSend();
    }

    /**
     * Use to enable/disable the continue hrp set
     *
     * @return the operate result
     */
    public boolean setContinueHrp(boolean enable) {
        if (D) Log.d(TAG, "setContinueHrp(), enable: " + enable);
        initialCommandSend();

        // Try to set long sit
        mApplicationLayer.sportDataCmdHrpContinueSet(enable, SPWristbandConfigInfo.getContinueHrpControlInterval(mContext));

        return waitCommandSend();
    }


    public boolean sendContinueHrpParamRequest() {
        if (D) Log.d(TAG, "sendContinueHrpParamRequest");
        initialCommandSend();

        // Try to set long sit
        mApplicationLayer.sportDataCmdHrpContinueParamRequest();

        return waitCommandSend();
    }

    /**
     * Use to enable/disable the turn over wrist
     *
     * @return the operate result
     */
    public boolean setTurnOverWrist(boolean enable) {
        if (D) Log.d(TAG, "setTurnOverWrist(), enable: " + enable);
        initialCommandSend();
        // Try to set long sit
        mApplicationLayer.settingCmdTurnOverWristSetting(enable);

        return waitCommandSend();
    }

    /**
     * Use to sync the long sit set
     *
     * @return the operate result
     */
    public boolean setLongSit(byte enable, int threshold, int notify, int start, int stop, byte dayflags) {
        if (D) Log.d(TAG, "setLongSit()");
        initialCommandSend();

        // Try to set long sit
        mApplicationLayer.settingCmdLongSitSetting(enable, threshold, notify, start, stop, dayflags);

        return waitCommandSend();
    }


    /**
     * Use to request current long sit set
     *
     * @return the operate result
     */
    public boolean sendLongSitRequest() {
        if (D) Log.d(TAG, "sendLongSitRequest()");
        initialCommandSend();
        // Need add this
        isNeedWaitForResponse = true;

        // Try to set long sit
        mApplicationLayer.settingCmdRequestLongSitSetting();

        return waitCommandSend();
    }

    /**
     * Use to request current long sit set
     *
     * @return the operate result
     */
    public boolean sendTurnOverWristRequest() {
        if (D) Log.d(TAG, "sendTurnOverWristRequest()");
        initialCommandSend();
        // Need add this
        isNeedWaitForResponse = true;

        // Try to set long sit
        mApplicationLayer.settingCmdRequestTurnOverWristSetting();

        return waitCommandSend();
    }

    /**
     * Use to sync the user profile, use local info
     *
     * @return the operate result
     */
    public boolean setUserProfile() {
        if (D) Log.d(TAG, "setUserProfile()");
        initialCommandSend();
        boolean sex = SPWristbandConfigInfo.getGendar(mContext);
        int age = SPWristbandConfigInfo.getAge(mContext);
        int height = SPWristbandConfigInfo.getHeight(mContext);
        int weight = SPWristbandConfigInfo.getWeight(mContext);

        // Try to set user profile
        mApplicationLayer.settingCmdUserSetting(sex, age, height, weight);

        return waitCommandSend();
    }

    /**
     * Use to sync the user profile
     *
     * @return the operate result
     */
    public boolean setUserProfile(boolean sex, int age, int height, int weight) {
        if (D) Log.d(TAG, "setUserProfile()");
        initialCommandSend();

        // Try to set user profile
        mApplicationLayer.settingCmdUserSetting(sex, age, height, weight);

        return waitCommandSend();
    }

    /**
     * Use to sync the target step, user local info
     *
     * @return the operate result
     */
    public boolean setTargetStep() {
        initialCommandSend();

        int step = SPWristbandConfigInfo.getTotalStep(mContext);
        if (D) Log.d(TAG, "setTargetStep, step: " + step);

        // Try to set step
        mApplicationLayer.settingCmdStepTargetSetting(step);

        return waitCommandSend();
    }

    /**
     * Use to sync the target step
     *
     * @return the operate result
     */
    public boolean setTargetStep(long step) {
        if (D) Log.d(TAG, "setTargetStep, step: " + step);
        initialCommandSend();

        // Try to set step
        mApplicationLayer.settingCmdStepTargetSetting(step);

        return waitCommandSend();
    }

    /**
     * Use to set the phone os
     *
     * @return the operate result
     */
    public boolean setPhoneOS() {
        if (D) Log.d(TAG, "setPhoneOS");
        initialCommandSend();

        // Try to set step
        mApplicationLayer.settingCmdPhoneOSSetting(ApplicationLayer.PHONE_OS_ANDROID);

        return waitCommandSend();
    }

    /**
     * Use to set the clocks
     *
     * @return the operate result
     */
    public boolean setClocks(ApplicationLayerAlarmsPacket alarms) {
        if (D) Log.d(TAG, "setClocks()");
        initialCommandSend();

        // Try to set alarms
        mApplicationLayer.settingCmdAlarmsSetting(alarms);

        return waitCommandSend();
    }

    /**
     * Use to set the clock
     *
     * @return the operate result
     */
    public boolean setClock(ApplicationLayerAlarmPacket alarm) {
        if (D) Log.d(TAG, "setClocks()");
        initialCommandSend();
        ApplicationLayerAlarmsPacket alarms = new ApplicationLayerAlarmsPacket();
        alarms.add(alarm);
        // Try to set alarms
        mApplicationLayer.settingCmdAlarmsSetting(alarms);

        return waitCommandSend();
    }

    /**
     * Use to sync the clock
     *
     * @return the operate result
     */
    public boolean setClocksSyncRequest() {
        if (D) Log.d(TAG, "SetClocksSyncRequest()");
        initialCommandSend();

        isNeedWaitForResponse = true;
        // Try to set alarms
        mApplicationLayer.settingCmdRequestAlarmList();

        return waitCommandSend();
    }

    /**
     * Use to sync the time
     *
     * @return the operate result
     */
    public boolean setTimeSync() {
        if (D) Log.d(TAG, "setTimeSync()");
        initialCommandSend();

        // Try to set time
        //in nexus9, Calendar's month is not right
        Calendar c1 = Calendar.getInstance();
        if (D) Log.d(TAG, "setTimeSync: " + c1.toString());
        mApplicationLayer.settingCmdTimeSetting(c1.get(Calendar.YEAR),
                c1.get(Calendar.MONTH) + 1, // here need add 1, because it origin range is 0 - 11;
                c1.get(Calendar.DATE),
                c1.get(Calendar.HOUR_OF_DAY),
                c1.get(Calendar.MINUTE),
                c1.get(Calendar.SECOND));
        /*
        Date d = new Date();
		if(D) Log.d(TAG, "setTimeSync: " + d.toString());
		mApplicationLayer.settingCmdTimeSetting(d.getYear(),
				d.getMonth(),
				d.getDate(),
				d.getHours(),
				d.getMinutes(),
				d.getSeconds());*/

        return waitCommandSend();
    }

    /**
     * Use to send the call notify info
     *
     * @return the operate result
     */
    public boolean sendCallNotifyInfo() {
        if (D) Log.d(TAG, "sendCallNotifyInfo");
        initialCommandSend();

        // Try to set alarms
        mApplicationLayer.notifyCmdCallNotifyInfoSetting();

        return waitCommandSend();
    }

    public boolean sendCallNotifyInfo(String show) {
        if (D) Log.d(TAG, "sendCallNotifyInfo");
        initialCommandSend();

        // Try to set alarms
        mApplicationLayer.notifyCmdCallNotifyInfoSetting(show);

        return waitCommandSend();
    }

    /**
     * Use to send the call accept notify info
     *
     * @return the operate result
     */
    public boolean sendCallAcceptNotifyInfo() {
        if (D) Log.d(TAG, "sendCallNotifyInfo");
        initialCommandSend();

        // Try to set alarms
        mApplicationLayer.notifyCmdCallAcceptNotifyInfoSetting();

        return waitCommandSend();
    }

    /**
     * Use to send the call reject notify info
     *
     * @return the operate result
     */
    public boolean sendCallRejectNotifyInfo() {
        if (D) Log.d(TAG, "sendCallNotifyInfo");
        initialCommandSend();

        // Try to set alarms
        mApplicationLayer.notifyCmdCallRejectNotifyInfoSetting();

        return waitCommandSend();
    }

    /**
     * Use to send the other notify info
     *
     * @return the operate result
     */
    public boolean sendOtherNotifyInfo(byte info) {
        if (D) Log.d(TAG, "SendOtherNotifyInfo, info: " + info);
        initialCommandSend();

        // Try to set alarms
        mApplicationLayer.notifyCmdOtherNotifyInfoSetting(info);

        return waitCommandSend();
    }

    public boolean sendOtherNotifyInfo(byte info, String show) {
        if (D) Log.d(TAG, "SendOtherNotifyInfo, info: " + info + "; showData: " + show);
        initialCommandSend();

        // Try to set alarms
        mApplicationLayer.notifyCmdOtherNotifyInfoSetting(info, show);

        return waitCommandSend();
    }

    /**
     * Use to send enable fac test mode
     *
     * @return the operate result
     */
    public boolean sendEnableFacTest() {
        if (D) Log.d(TAG, "SendEnableFacTest");
        if (mWristState != STATE_WRIST_INITIAL) {
            return false;
        }
        initialCommandSend();

        // Try to set alarms
        mApplicationLayer.facCmdEnterTestMode(null);

        return waitCommandSend();
    }

    /**
     * Use to send disable fac test mode
     *
     * @return the operate result
     */
    public boolean sendDisableFacTest() {
        if (D) Log.d(TAG, "SendDisableFacTest");
        if (mWristState != STATE_WRIST_ENTER_TEST_MODE) {
            return false;
        }
        initialCommandSend();

        // Try to set alarms
        mApplicationLayer.facCmdExitTestMode(null);

        return waitCommandSend();
    }

    /**
     * Use to send enable led
     *
     * @param led the led want to enable
     * @return the operate result
     */
    public boolean sendEnableFacLed(byte led) {
        if (D) Log.d(TAG, "SendEnableFacLed");
        initialCommandSend();

        // Try to set alarms
        mApplicationLayer.facCmdEnableLed(led);

        return waitCommandSend();
    }

    /**
     * Use to send enable vibrate
     *
     * @return the operate result
     */
    public boolean sendEnableFacVibrate() {
        if (D) Log.d(TAG, "SendEnableFacVibrate");
        initialCommandSend();

        // Try to set alarms
        mApplicationLayer.facCmdEnableVibrate();

        return waitCommandSend();
    }

    /**
     * Use to send request sensor data
     *
     * @return the operate result
     */
    public boolean sendEnableFacSensorDataRequest() {
        if (D) Log.d(TAG, "SendEnableFacSensorData");
        initialCommandSend();

        // Try to set alarms
        mApplicationLayer.facCmdRequestSensorData();

        return waitCommandSend();
    }

    /**
     * Use to send open log command
     *
     * @return the operate result
     */
    public boolean sendLogEnableCommand(byte[] keyArray) {
        if (D) Log.d(TAG, "SendLogEnableCommand");
        initialCommandSend();

        mApplicationLayer.logCmdOpenLog(keyArray);

        return waitCommandSend();
    }

    public boolean sendLogEnableCommand() {
        int cnt = 0;
        byte[] temp = new byte[DEBUG_LOG_TYPE_MAX_CNT];
        if (SPWristbandConfigInfo.getDebugLogTypeModuleApp(mContext)) {
            temp[cnt] = ApplicationLayer.DEBUG_LOG_TYPE_MODULE_APP;
            cnt++;
        }
        if (SPWristbandConfigInfo.getDebugLogTypeModuleUpperStack(mContext)) {
            temp[cnt] = ApplicationLayer.DEBUG_LOG_TYPE_MODULE_UPSTACK;
            cnt++;
        }
        if (SPWristbandConfigInfo.getDebugLogTypeModuleLowerStack(mContext)) {
            temp[cnt] = ApplicationLayer.DEBUG_LOG_TYPE_MODULE_LOWERSTACK;
            cnt++;
        }
        if (SPWristbandConfigInfo.getDebugLogTypeSleep(mContext)) {
            temp[cnt] = ApplicationLayer.DEBUG_LOG_TYPE_SLEEP_DATA;
            cnt++;
        }
        if (SPWristbandConfigInfo.getDebugLogTypeSport(mContext)) {
            temp[cnt] = ApplicationLayer.DEBUG_LOG_TYPE_SPORT_DATA;
            cnt++;
        }
        if (SPWristbandConfigInfo.getDebugLogTypeConfig(mContext)) {
            temp[cnt] = ApplicationLayer.DEBUG_LOG_TYPE_CONFIG_DATA;
            cnt++;
        }
        if (cnt == 0) {
            if (D) Log.i(TAG, "No need to enable log.");
            return true;
        }
        byte[] keyArray = new byte[cnt];
        System.arraycopy(temp, 0, keyArray, 0, cnt);

        return sendLogEnableCommand(keyArray);
    }

    /**
     * Use to send open log command
     *
     * @return the operate result
     */
    public boolean sendLogCloseCommand() {
        if (D) Log.d(TAG, "SendLogCloseCommand");
        initialCommandSend();

        mApplicationLayer.logCmdCloseLog();

        return waitCommandSend();
    }

    /**
     * Use to send request log command
     *
     * @return the operate result
     */
    public boolean sendLogRequestCommand(byte key) {
        if (D) Log.d(TAG, "SendLogRequestCommand");
        initialCommandSend();

        mApplicationLayer.logCmdRequestLog(key);

        return waitCommandSend();
    }

    /**
     * Use to send sync today step command
     *
     * @return the operate result
     */
    public boolean sendSyncTodayNearlyOffsetStepCommand() {
        if (D) Log.d(TAG, "SendSyncTodayNearlyOffsetStepCommand");
        initialCommandSend();
        Calendar c1 = Calendar.getInstance();
//		List<SportData> sports = mGlobalGreenDAO.loadSportDataByDate(c1.get(Calendar.YEAR),
//				c1.get(Calendar.MONTH) + 1,// here need add 1, because it origin range is 0 - 11;
//				c1.get(Calendar.DATE));
//
//		SportData subData = WristbandCalculator.getNearlyOffsetStepData(sports);

//		ApplicationLayerRecentlySportPacket packet;
//		mApplicationLayer.sportDataCmdSyncRecently((byte)(subData.getMode() & 0xff)
//					, subData.getActiveTime()
//					, subData.getCalory()
//					, subData.getStepCount()
//					, subData.getDistance());
//		if(subData != null) {
//			packet = new ApplicationLayerRecentlySportPacket((byte)(subData.getMode() & 0xff)
//					, subData.getActiveTime()
//					, subData.getCalory()
//					, subData.getStepCount()
//					, subData.getDistance());
//		} else {
        // Try to sync total step data
        mApplicationLayer.sportDataCmdSyncRecently((byte) 0x00
                , 0
                , 0
                , 0
                , 0);
//			packet = new ApplicationLayerRecentlySportPacket((byte)0x00
//					, 0
//					, 0
//					, 0
//					, 0);
//		}
        // Try to sync total step data
//		mApplicationLayer.sportDataCmdSyncRecently(packet);

        return waitCommandSend();
    }

    /**
     * Use to send remove bond command
     *
     * @return the operate result
     */
    boolean sendRemoveBondCommand() {

        if (D) Log.d(TAG, "SendRemoveBondCommand");
        initialCommandSend();

        // Try to set alarms
        mApplicationLayer.bondCmdRequestRemoveBond();

        // when send remove bond command, we just think link is lost.
        isConnected = false;
        return waitCommandSend();
    }

    /**
     * Use to send camera control command
     *
     * @return the operate result
     */
    public boolean sendCameraControlCommand(boolean enable) {
        if (D) Log.d(TAG, "SendCameraControlCommand, enable: " + enable);
        initialCommandSend();

        // Try to set alarms
        mApplicationLayer.controlCmdCameraControl(
                enable ? ApplicationLayer.CAMERA_CONTROL_APP_IN_FORE : ApplicationLayer.CAMERA_CONTROL_APP_IN_BACK);

        return waitCommandSend();
    }

    /**
     * Set the remote left right hand. Command: 0x02, Key: 0x22.
     * <p>This is an asynchronous operation. Once the operation has been completed, the
     * {@link ApplicationLayerCallback#onCommandSend} callback is invoked,
     * reporting the result of the operation.
     *
     * @param mode the left right hand mode. 0x01 is left ; 0x02 is right;
     * @return the operation result
     */
    public boolean settingCmdLeftRightSetting(byte mode) {
        if (D) Log.d(TAG, "settingCmdLeftRightSetting, enable: " + mode);
        initialCommandSend();

        mApplicationLayer.settingCmdLeftRightSetting(mode);

        return waitCommandSend();
    }

    /**
     * Use to send sync today step command
     *
     * @return the operate result
     */
    public boolean sendSyncTodayStepCommand() {
        if (D) Log.d(TAG, "SendSyncTodayStepCommand");
        initialCommandSend();
        Calendar c1 = Calendar.getInstance();
//		List<SportData> sports = mGlobalGreenDAO.loadSportDataByDate(c1.get(Calendar.YEAR),
//				c1.get(Calendar.MONTH) + 1,// here need add 1, because it origin range is 0 - 11;
//				c1.get(Calendar.DATE));
//
//		SportSubData subData = WristbandCalculator.sumOfSportDataByDate(c1.get(Calendar.YEAR),
//				c1.get(Calendar.MONTH) + 1,// here need add 1, because it origin range is 0 - 11;
//				c1.get(Calendar.DATE),
//				sports);
        ApplicationLayerTodaySportPacket packet;
//		if(subData != null) {
//			packet = new ApplicationLayerTodaySportPacket((long)subData.getStepCount()
//					, (long)subData.getDistance()
//					, (long)subData.getCalory());
//		} else {
        packet = new ApplicationLayerTodaySportPacket(0
                , 0
                , 0);
//		}
        // Try to sync total step data
        mApplicationLayer.sportDataCmdSyncToday(0, 0, 0);

        return waitCommandSend();
    }

    public boolean isInSendCommand() {
        return this.isInSendCommand;
    }

    private boolean initialCommandSend() {
        if (D) Log.d(TAG, "initialCommandSend()");
        // Here we need do more thing for queue send command, current version didn't fix it.


        while (isInSendCommand || isNeedWaitForResponse) {
            if (!isConnect()) {
                return false;
            }
            if (D)
                Log.d(TAG, "Wait for last command send ok. isInSendCommand: " + isInSendCommand + ", isNeedWaitForResponse: " + isNeedWaitForResponse);
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        synchronized (mCommandSendLock) {
            // init status
            mErrorStatus = false;
            isCommandSend = false;
            isCommandSendOk = false;

            isInSendCommand = true;
        }

        return true;
    }

    private boolean waitCommandSend() {
        if (D) Log.d(TAG, "waitCommandSend()");
        boolean commendSendReady = false;
        synchronized (mCommandSendLock) {
            if (D) Log.d(TAG, "mCommandSendLock isCommandSend :" + isCommandSend);

            if (!isCommandSend) {
                try {
                    // wait a while
                    if (D)
                        Log.d(TAG, "wait the time set callback, wait for: " + MAX_COMMAND_SEND_WAIT_TIME + "ms");
                    mCommandSendLock.wait(MAX_COMMAND_SEND_WAIT_TIME);

                    if (D) Log.d(TAG, "waitCommandSend, isCommandSendOk: " + isCommandSendOk);
                    isInSendCommand = false;

                    commendSendReady = isCommandSendOk;
                } catch (InterruptedException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }
        }
        if (D) Log.d(TAG, "waitCommandSend return :" + commendSendReady);
        return commendSendReady;
    }


    // Login response
    private boolean mLoginResponse;
    private int mLoginResponseStatus;

    /**
     * Request Login
     *
     * @return the login result, fail or success
     * @id the user id
     */
    private boolean RequestLogin(String id) {
        if (D) Log.d(TAG, "RequestLogin, id: " + id);
        // init error status
        mErrorStatus = false;
        isResponseCome = false;
        mLoginResponse = false;
        mLoginResponseStatus = LOGIN_RSP_SUCCESS;


        // Try to login
        mApplicationLayer.bondCmdRequestLogin(id);// it will wait the onBondCmdRequestLogin callback invoke.

        synchronized (mRequestResponseLock) {
            if (!isResponseCome) {
                try {
                    // wait a while
                    if (D)
                        Log.d(TAG, "wait the login response come, wait for: " + MAX_REQUEST_RESPONSE_TRANSACTION_WAIT_TIME + "ms");
                    mRequestResponseLock.wait(MAX_REQUEST_RESPONSE_TRANSACTION_WAIT_TIME);
                } catch (InterruptedException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }
        }

        if (!isResponseCome) {
            mErrorStatus = true;
            return false;
        }

        if (!mLoginResponse) {
            setDataSync(false);
        }

        if (isResponseCome
                && (mLoginResponseStatus == ApplicationLayer.LOGIN_LOSS_LOGIN_INFO)) {
            //
            Log.w(TAG, "Be-careful, may be last connection loss sync info, do again.");
            requestSetNeedInfo();
            // update state
            updateWristState(STATE_WRIST_LOGIN);
        }
        return mLoginResponse;
    }

    // Login response
    private boolean mBondResponse;

    /**
     * Request Bond
     *
     * @return the bond result, fail or success
     * @id the user id
     */
    private boolean RequestBond(String id) {
        if (D) Log.d(TAG, "RequestBond, id: " + id);
        // init error status
        mErrorStatus = false;
        isResponseCome = false;
        mBondResponse = false;

        // Try to login
        mApplicationLayer.bondCmdRequestBond(id);// it will wait the onBondCmdRequestLogin callback invoke.

        synchronized (mRequestResponseLock) {
            if (!isResponseCome) {
                try {
                    // wait a while
                    if (D)
                        Log.d(TAG, "wait the bond response come, wait for: " + MAX_REQUEST_RESPONSE_TRANSACTION_WAIT_TIME + "ms");
                    mRequestResponseLock.wait(MAX_REQUEST_RESPONSE_TRANSACTION_WAIT_TIME);
                } catch (InterruptedException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }
        }

        if (!isResponseCome) {
            mErrorStatus = true;
            return false;
        }
        return mBondResponse;
    }

    public boolean isReady() {
        if (D) Log.d(TAG, "isReady, mWristState: " + mWristState);
        return mWristState == STATE_WRIST_SYNC_DATA;
    }

    /**
     * Use to set the remote Immediate Alert Level
     *
     * @param enable enable/disable Immediate Alert
     */
    public boolean enableImmediateAlert(boolean enable) {
        initialCommandSend();
        boolean result = mImmediateAlertService.enableAlert(enable);
        isInSendCommand = false;
        return result;
    }

    /**
     * Use to set the remote Link Loss Alert Level
     *
     * @param enable enable/disable Link Loss Alert
     */
    public boolean enableLinkLossAlert(boolean enable) {
        initialCommandSend();
        boolean result = mLinkLossService.enableAlert(enable);
        isInSendCommand = false;
        return result;
    }

    /**
     * Use to read the remote Battery Level
     */
    public boolean readBatteryLevel() {
        if (D) Log.d(TAG, "readBatteryLevel");
        //isInSendCommand = true;
        initialCommandSend();

        boolean result = mBatteryService.readInfo();

        isInSendCommand = false;
        return result;
    }

    /**
     * Use to read the remote Hrp Level
     */
    public boolean readHrpValue() {
        if (D) Log.d(TAG, "readHrpValue");
        initialCommandSend();

        mApplicationLayer.sportDataCmdHrpSingleRequest(true);

        return waitCommandSend();
    }

    /**
     * Use to read the remote Hrp Level
     */
    public boolean stopReadHrpValue() {
        if (D) Log.d(TAG, "stopReadHrpValue");
        //isInSendCommand = true;
        initialCommandSend();

        mApplicationLayer.sportDataCmdHrpSingleRequest(false);

        return waitCommandSend();
    }


    /**
     * Use to read the remote Link loss Level
     */
    public boolean readLinkLossLevel() {
        if (D) Log.d(TAG, "readLinkLossLevel");
        initialCommandSend();

        if (!mLinkLossService.readInfo()) {
            if (D) Log.e(TAG, "readLinkLossLevel, failed");
            return false;
        }

        return waitCommandSend();
    }

    /**
     * Use to read the remote version info
     */
    public boolean readDfuVersion() {
        if (D) Log.d(TAG, "readDfuVersion");
        initialCommandSend();

        if (!mDfuService.readInfo()) {
            if (D) Log.e(TAG, "readDfuVersion, failed");
            return false;
        }

        return waitCommandSend();
    }

    /**
     * Use to get the remote Battery Level
     */
    public int getBatteryLevel() {
        if (mBatteryService != null) {
            return mBatteryService.getBatteryValue();
        } else {
            return -1;
        }
    }

    /**
     * Use to check support extend flash
     */
    public boolean checkSupportedExtendFlash() {
        if (mDfuService != null) {
            return mDfuService.checkSupportedExtendFlash();
        } else {
            return false;
        }
    }

    /**
     * Check if there is a new firmware version
     *
     * @param vendor
     * @param deviceType
     */
    public void checkNewFwVersion(String vendor, String deviceType) {
        mDfuService.checkNewFWVersion(vendor, deviceType);
    }

    public int getCurrentFWVersion() {
        return mDfuService.getAppValue();
    }


    /**
     * Use to enable battery power notification
     */
    public boolean enableBatteryNotification(boolean enable) {
        initialCommandSend();
        // enable notification
        boolean result = mBatteryService.enableNotification(enable);
        isInSendCommand = false;
        return result;
    }

    // notify control
    public void registerNotifyBroadcast() {
        if (D) Log.i(TAG, "registerNotifyBroadcast");
        unregisterNotifyBroadcast();
        mNotifyBroadcastReceive = new NotifyBroadcastReceive(this);
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(NotifyBroadcastReceive.ACTION_BROADCAST_CALL);
        intentFilter.addAction(NotifyBroadcastReceive.ACTION_BROADCAST_SMS);
        intentFilter.addAction(NotificationReceive.BROADCAST_TYPE);
        intentFilter.setPriority(Integer.MAX_VALUE);
        mContext.registerReceiver(mNotifyBroadcastReceive, intentFilter);
    }

    public void unregisterNotifyBroadcast() {
        if (D) Log.i(TAG, "unregisterNotifyBroadcast");
        if (mNotifyBroadcastReceive != null) {
            mContext.unregisterReceiver(mNotifyBroadcastReceive);
            mNotifyBroadcastReceive = null;
        }
    }

    public void registerDateChangeBroadcast() {
        if (D) Log.i(TAG, "registerDateChangeBroadcast");
        unregisterDateChangeBroadcast();
        mSystemDateChangeBroadcastReceive = new SystemDateChangeBroadcastReceive();
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(SystemDateChangeBroadcastReceive.ACTION_TIMEZONE_CHANGED);
        intentFilter.addAction(SystemDateChangeBroadcastReceive.ACTION_DATE_CHANGED);
        intentFilter.addAction(SystemDateChangeBroadcastReceive.ACTION_TIME_CHANGED);
        intentFilter.setPriority(Integer.MAX_VALUE);
        mContext.registerReceiver(mSystemDateChangeBroadcastReceive, intentFilter);
    }

    public void unregisterDateChangeBroadcast() {
        if (D) Log.i(TAG, "unregisterDateChangeBroadcast");
        if (mSystemDateChangeBroadcastReceive != null) {
            mContext.unregisterReceiver(mSystemDateChangeBroadcastReceive);
            mSystemDateChangeBroadcastReceive = null;
        }
    }


    // The Handler that gets information back from test thread
    //private class MyHandler extends Handler {
    private Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case MSG_STATE_CONNECTED:
                    isConnected = true;
                    synchronized (mCallbacks) {
                        for (ControlManagerCallback callback : mCallbacks) {
                            if (null == callback) continue;
                            callback.onConnectionStateChange(true);
                        }
                    }
                    //mCallback.onConnectionStateChange(true);
                    break;
                case MSG_STATE_DISCONNECTED:
//                    if (isConnect()
//                            && mWristState >= STATE_WRIST_LOGIN) {// Only login may call lost alert
//                        if (!SPWristbandConfigInfo.getControlSwitchLost(mContext)) {
//                            if (D) Log.i(TAG, "Lost alarm didn't enable.");
//                        } else {
//                            mAlertDialog = new AlertDialog.Builder(mContext, AlertDialog.THEME_HOLO_LIGHT).create();
//                            mAlertDialog.setMessage(mContext.getString(R.string.connect_disconnect));
//                            mAlertDialog.setTitle(R.string.app_name);
//                            mAlertDialog.setButton(AlertDialog.BUTTON_POSITIVE, mContext.getString(R.string.cancel), new DialogInterface.OnClickListener() {
//                                @Override
//                                public void onClick(DialogInterface dialog, int which) {
//                                    stopAlarm();
//                                    dialog.dismiss();
//                                }
//                            });
//                            mAlertDialog.setCancelable(false);
//                            //mAlertDialog.getWindow().setType(WindowManager.LayoutParams.TYPE_SYSTEM_ALERT);
//                            mAlertDialog.getWindow().setType(WindowManager.LayoutParams.TYPE_TOAST);
//                            mAlertDialog.show();
//
//                            playAlarm();
//                        }
//                    }
                    isConnected = false;
                    synchronized (mCallbacks) {
                        // do something
                        for (ControlManagerCallback callback : mCallbacks) {
                            callback.onConnectionStateChange(false);
                        }
                        // close all
                        close();
                    }
                    //mCallback.onConnectionStateChange(false);
                    break;
                case MSG_ERROR:
                    synchronized (mCallbacks) {
                        // do something
                        for (ControlManagerCallback callback : mCallbacks) {
                            callback.onError(msg.arg1);
                        }
                    }
                    //mCallback.onError(msg.arg1);
                    break;
                case MSG_WRIST_STATE_CHANGED:
                    if (D) Log.d(TAG, "MSG_WRIST_STATE_CHANGED, current state: " + msg.arg1);
                    // show state
                    synchronized (mCallbacks) {
                        // do something
                        for (ControlManagerCallback callback : mCallbacks) {
                            callback.onLoginStateChange(msg.arg1);
                        }
                    }
                    //mCallback.onLoginStateChange(msg.arg1);
                    break;
                case MSG_RECEIVE_SPORT_INFO:

                    synchronized (mCallbacks) {
                        if (D) Log.d(TAG, "MSG_RECEIVE_SPORT_INFO, current state: " + msg.arg1);

                        for (ControlManagerCallback callback : mCallbacks) {
                            callback.onSportDataReceiveIndication((ApplicationLayerSportPacket) msg.obj);
                        }
                    }

                    break;
                case MSG_RECEIVE_HISTORY_SPORT_INFO:
                    synchronized (mCallbacks) {
                        if (D) Log.d(TAG, "MSG_RECEIVE_HISTORY_SPORT_INFO, current state: " + msg.arg1);
                        for (ControlManagerCallback callback : mCallbacks) {
                            callback.onSportDataCmdHistorySyncEnd((ApplicationLayerSportPacket) msg.obj);
                        }
                    }
                    break;

                case MSG_RECEIVE_SLEEP_INFO:
                    synchronized (mCallbacks) {
                        for (ControlManagerCallback callback : mCallbacks) {
                            callback.onSleepDataReceiveIndication((ApplicationLayerSleepPacket) msg.obj);
                        }
                    }

                    break;
                case MSG_RECEIVE_NOTIFY_MODE_SETTING:
                    byte mode = (byte) msg.obj;
                    if (D) Log.w(TAG, "Current notify setting is: " + mode);
                    SPWristbandConfigInfo.setNotifyCallFlag(mContext, (mode & ApplicationLayer.NOTIFY_SWITCH_SETTING_CALL) != 0);
                    SPWristbandConfigInfo.setNotifyMessageFlag(mContext, (mode & ApplicationLayer.NOTIFY_SWITCH_SETTING_MESSAGE) != 0);
                    if (isNotifyManageEnabled()) {
                        SPWristbandConfigInfo.setNotifyQQFlag(mContext, (mode & ApplicationLayer.NOTIFY_SWITCH_SETTING_QQ) != 0);
                        SPWristbandConfigInfo.setNotifyWechatFlag(mContext, (mode & ApplicationLayer.NOTIFY_SWITCH_SETTING_WECHAT) != 0);
                    } else {
                        if (D) Log.w(TAG, "Notify not enable, should not enable these setting.");
                    }

                    synchronized (mRequestResponseLock) {
                        isResponseCome = true;
                        isNeedWaitForResponse = false;
                        mRequestResponseLock.notifyAll();
                    }
                    synchronized (mCallbacks) {
                        for (ControlManagerCallback callback : mCallbacks) {
                            callback.onNotifyModeSettingReceive(mode);
                        }
                    }
                    break;
                case MSG_RECEIVE_LONG_SIT_SETTING:
                    byte longsitmode = (byte) msg.obj;
                    if (D) Log.w(TAG, "Current long sit setting is: " + longsitmode);
                    SPWristbandConfigInfo.setControlSwitchLongSit(mContext, longsitmode == ApplicationLayer.LONG_SIT_CONTROL_ENABLE);
                    synchronized (mRequestResponseLock) {
                        isResponseCome = true;
                        isNeedWaitForResponse = false;
                        mRequestResponseLock.notifyAll();
                    }
                    synchronized (mCallbacks) {
                        for (ControlManagerCallback callback : mCallbacks) {
                            callback.onLongSitSettingReceive(longsitmode);
                        }
                    }
                    break;
                case MSG_RECEIVE_TURN_OVER_WRIST_SETTING:
                    boolean enable = (boolean) msg.obj;
                    if (D) Log.w(TAG, "Current turn over wrist setting is: " + enable);
                    SPWristbandConfigInfo.setControlSwitchTurnOverWrist(mContext, enable);
                    synchronized (mRequestResponseLock) {
                        isResponseCome = true;
                        isNeedWaitForResponse = false;
                        mRequestResponseLock.notifyAll();
                    }
                    synchronized (mCallbacks) {
                        for (ControlManagerCallback callback : mCallbacks) {
                            callback.onTurnOverWristSettingReceive(enable);
                        }
                    }
                    break;

                case MSG_RECEIVE_ALARMS_INFO:
                    //Reset all first.
                    SPWristbandConfigInfo.setAlarmControlOne(mContext, false);
                    SPWristbandConfigInfo.setAlarmControlTwo(mContext, false);
                    SPWristbandConfigInfo.setAlarmControlThree(mContext, false);

                    ApplicationLayerAlarmsPacket alarmPacket = (ApplicationLayerAlarmsPacket) msg.obj;
                    for (final ApplicationLayerAlarmPacket p : alarmPacket.getAlarms()) {
                        byte dayFlag = p.getDayFlags();
                        String hour = String.valueOf(p.getHour()).length() == 1
                                ? "0" + String.valueOf(p.getHour())
                                : String.valueOf(p.getHour());
                        String minute = String.valueOf(p.getMinute()).length() == 1
                                ? "0" + String.valueOf(p.getMinute())
                                : String.valueOf(p.getMinute());
                        String timeString = hour + ":" + minute;
                        // set check
                        if (p.getId() == 0) {
                            SPWristbandConfigInfo.setAlarmControlOne(mContext, true);
                            SPWristbandConfigInfo.setAlarmTimeOne(mContext, timeString);
                            SPWristbandConfigInfo.setAlarmFlagOne(mContext, dayFlag);
                        } else if (p.getId() == 1) {
                            SPWristbandConfigInfo.setAlarmControlTwo(mContext, true);
                            SPWristbandConfigInfo.setAlarmTimeTwo(mContext, timeString);
                            SPWristbandConfigInfo.setAlarmFlagTwo(mContext, dayFlag);
                        } else {
                            SPWristbandConfigInfo.setAlarmControlThree(mContext, true);
                            SPWristbandConfigInfo.setAlarmTimeThree(mContext, timeString);
                            SPWristbandConfigInfo.setAlarmFlagThree(mContext, dayFlag);
                        }
                        //mCallback.onSleepDataReceive(sleepData);
                    }
                    synchronized (mRequestResponseLock) {
                        isResponseCome = true;
                        isNeedWaitForResponse = false;
                        mRequestResponseLock.notifyAll();
                    }
                    synchronized (mCallbacks) {
                        for (ControlManagerCallback callback : mCallbacks) {
                            callback.onAlarmsDataReceive(alarmPacket);
                        }
                    }
                    break;
                case MSG_RECEIVE_TAKE_PHOTO_RSP:
                    if (D) Log.d(TAG, "MSG_RECEIVE_TAKE_PHOTO_RSP");
                    synchronized (mCallbacks) {
                        // do something
                        for (ControlManagerCallback callback : mCallbacks) {
                            callback.onTakePhotoRsp();
                        }
                    }
                    break;
                case MSG_RECEIVE_FAC_SENSOR_INFO:
                    if (D) Log.d(TAG, "MSG_RECEIVE_FAC_SENSOR_INFO");
                    ApplicationLayerFacSensorPacket sensorPacket = (ApplicationLayerFacSensorPacket) msg.obj;
                    if (D) Log.d(TAG, "Receive Fac Sensor info, X: " + sensorPacket.getX() +
                            ", Y: " + sensorPacket.getY() +
                            ", Z: " + sensorPacket.getZ());
                    // show state
                    synchronized (mCallbacks) {
                        // do something
                        for (ControlManagerCallback callback : mCallbacks) {
                            callback.onFacSensorDataReceive(sensorPacket);
                        }
                    }
                    break;
                case MSG_RECEIVE_LOG_START:
                    if (D) Log.d(TAG, "MSG_RECEIVE_LOG_START");
                    long logLength = (long) msg.obj;

                    // show state
                    synchronized (mCallbacks) {
                        // do something
                        for (ControlManagerCallback callback : mCallbacks) {
                            callback.onLogCmdStart(logLength);
                        }
                    }
                    break;
                case MSG_RECEIVE_LOG_END:
                    if (D) Log.d(TAG, "MSG_RECEIVE_LOG_END");
                    // show state
                    synchronized (mCallbacks) {
                        // do something
                        for (ControlManagerCallback callback : mCallbacks) {
                            callback.onLogCmdEnd();
                        }
                    }
                    break;
                case MSG_RECEIVE_LOG_RSP:
                    if (D) Log.d(TAG, "MSG_RECEIVE_LOG_RSP");
                    ApplicationLayerLogResponsePacket logResponsePacket = (ApplicationLayerLogResponsePacket) msg.obj;
                    // show state
                    synchronized (mCallbacks) {
                        // do something
                        for (ControlManagerCallback callback : mCallbacks) {
                            callback.onLogCmdRsp(logResponsePacket);
                        }
                    }
                    break;
                case MSG_RECEIVE_DFU_VERSION_INFO:
                    if (D) Log.d(TAG, "MSG_RECEIVE_DFU_VERSION_INFO");
                    int appVersion = msg.arg1;
                    int patchVersion = msg.arg2;
                    if (D) Log.d(TAG, "Receive dfu version info, appVersion: " + appVersion +
                            ", patchVersion: " + patchVersion);
                    // show state
                    synchronized (mCallbacks) {
                        // do something
                        for (ControlManagerCallback callback : mCallbacks) {
                            callback.onVersionRead(appVersion, patchVersion);
                        }
                    }
                    break;
                case MSG_RECEIVE_DEVICE_NAME_INFO:
                    if (D) Log.d(TAG, "MSG_RECEIVE_DEVICE_NAME_INFO");
                    String name = (String) msg.obj;
                    if (D) Log.d(TAG, "Receive device name info, name: " + name);
                    // show state
                    synchronized (mCallbacks) {
                        // do something
                        for (ControlManagerCallback callback : mCallbacks) {
                            callback.onNameRead(name);
                        }
                    }
                    break;
                case MSG_RECEIVE_BATTERY_INFO:
                    if (D) Log.d(TAG, "MSG_RECEIVE_BATTERY_INFO");
                    int battery = msg.arg1;
                    synchronized (mCallbacks) {
                        for (ControlManagerCallback callback : mCallbacks) {
                            callback.onBatteryRead(battery);
                        }
                    }
                    break;
                case MSG_RECEIVE_BATTERY_CHANGE_INFO:
                    if (D) Log.d(TAG, "MSG_RECEIVE_BATTERY_CHANGE_INFO");
                    int batteryChange = msg.arg1;

                    if (batteryChange <= 20) {
                        // send broadcast
                        MyNotificationManager.getInstance().sendBatteryAlarmNotification(mContext.getString(R.string.notify_battery_alarm_string));
                    }
                    synchronized (mCallbacks) {
                        for (ControlManagerCallback callback : mCallbacks) {
                            callback.onBatteryChange(batteryChange);
                        }
                    }
                    break;
                case MSG_RECEIVE_HRP_INFO:
                    if (D) Log.d(TAG, "MSG_RECEIVE_HRP_INFO");
                    ApplicationLayerHrpPacket hrpPacket = (ApplicationLayerHrpPacket) msg.obj;
                    for (ApplicationLayerHrpItemPacket p : hrpPacket.getHrpItems()) {
                        if (D) Log.d(TAG, "Find a hrp item, Minutes: " + p.getMinutes() +
                                ", Value: " + p.getValue());

                        synchronized (mCallbacks) {
                            for (ControlManagerCallback callback : mCallbacks) {
                                callback.onHrpDataReceiveIndication(p.getValue());
                            }
                        }
                    }
                    break;
                case MSG_RECEIVE_HRP_DEVICE_CANCEL_SINGLE_READ:
                    if (D) Log.d(TAG, "MSG_RECEIVE_HRP_DEVICE_CANCEL_SINGLE_READ");

                    synchronized (mCallbacks) {
                        for (ControlManagerCallback callback : mCallbacks) {
                            callback.onDeviceCancelSingleHrpRead();
                        }
                    }
                    break;
                case MSG_RECEIVE_HRP_CONTINUE_PARAM_RSP:
                    if (D) Log.d(TAG, "MSG_RECEIVE_HRP_CONTINUE_PARAM_RSP");
                    /*
                    synchronized (mCallbacks) {
						for (ControlManagerCallback callback : mCallbacks) {
							callback.onDeviceCancelSingleHrpRead();
						}
					}*/
                    break;
                default:
                    break;
            }
        }
    };

    // Application Layer callback
    private final ApplicationLayerCallback mApplicationCallback = new ApplicationLayerCallback() {
        @Override
        public void onConnectionStateChange(final boolean status, final boolean newState) {
            if (D)
                Log.d(TAG, "onConnectionStateChange, status: " + status + ", newState: " + newState);
            // if already connect to the remote device, we can do more things here.
            if (status && newState) {
                sendMessage(MSG_STATE_CONNECTED, null, -1, -1);
            } else {
                sendMessage(MSG_STATE_DISCONNECTED, null, -1, -1);
            }
        }

        @Override
        public void onSettingCmdRequestAlarmList(final ApplicationLayerAlarmsPacket alarms) {
            if (D) Log.d(TAG, "ApplicationLayerAlarmsPacket");
            sendMessage(MSG_RECEIVE_ALARMS_INFO, alarms, -1, -1);
        }

        @Override
        public void onSettingCmdRequestNotifySwitch(final byte mode) {
            if (D) Log.d(TAG, "onSettingCmdRequestNotifySwitch");
            sendMessage(MSG_RECEIVE_NOTIFY_MODE_SETTING, mode, -1, -1);
        }

        @Override
        public void onSettingCmdRequestLongSit(final byte mode) {
            if (D) Log.d(TAG, "onSettingCmdRequestLongSit");
            sendMessage(MSG_RECEIVE_LONG_SIT_SETTING, mode, -1, -1);
        }

        @Override
        public void onTurnOverWristSettingReceive(final boolean mode) {
            if (D) Log.d(TAG, "onTurnOverWristSettingReceive");
            sendMessage(MSG_RECEIVE_TURN_OVER_WRIST_SETTING, mode, -1, -1);
        }

        @Override
        public void onSportDataCmdSportData(final ApplicationLayerSportPacket sport) {
            if (D)
                Log.d(TAG, "onSportDataCmdSportData with ControlManager state is " + mWristState);
            ApplicationLayerSportPacket sportPacket = sport;
            if (D) Log.d(TAG, "Receive a sport packet, Year: " + (sportPacket.getYear() + 2000) +
                    ", Month: " + sportPacket.getMonth() +
                    ", Day: " + sportPacket.getDay() +
                    ", Item count: " + sportPacket.getItemCount());
            for (ApplicationLayerSportItemPacket p : sportPacket.getSportItems()) {
                if (D) Log.d(TAG, "Find a sport item, Offset: " + p.getOffset() +
                        ", Mode: " + p.getMode() +
                        ", Step count: " + p.getStepCount() +
                        ", Active time: " + p.getActiveTime() +
                        ", Calory: " + p.getCalory() +
                        ", Distance: " + p.getDistance());
// TODO: 07/06/17  save sport data
//				SportData sportData = new SportData(null, sportPacket.getYear() + 2000, sportPacket.getMonth(), sportPacket.getDay(),
//						p.getOffset(), p.getMode(), p.getStepCount(), p.getActiveTime(), p.getCalory(), p.getDistance(), new Date());
//				mGlobalGreenDAO.saveSportData(sportData);
            }
            if (D) Log.d(TAG, "mWristState != STATE_WRIST_SYNC_HISTORY_DATA>>>>>>>>>>>1");


            if (mWristState != STATE_WRIST_SYNC_HISTORY_DATA) {
                if (D)
                    Log.d(TAG, "mWristState != STATE_WRIST_SYNC_HISTORY_DATA>>>>>>>>>>>2" + sport.getItemCount());

                sendMessage(MSG_RECEIVE_SPORT_INFO, sport, -1, -1);
            } else {
                sendMessage(MSG_RECEIVE_HISTORY_SPORT_INFO, sport, -1, -1);
            }
        }

        @Override
        public void onSportDataCmdSleepData(final ApplicationLayerSleepPacket sleep) {
            if (D) Log.d(TAG, "onSportDataCmdSleepData");
            ApplicationLayerSleepPacket sleepPacket = sleep;
            if (D) Log.d(TAG, "Receive a sleep packet, Year: " + (sleepPacket.getYear() + 2000) +
                    ", Month: " + sleepPacket.getMonth() +
                    ", Day: " + sleepPacket.getDay() +
                    ", Item count: " + sleepPacket.getItemCount());
            for (ApplicationLayerSleepItemPacket p : sleepPacket.getSleepItems()) {
                if (D) Log.d(TAG, "Find a sleep item, Minutes: " + p.getMinutes() +
                        ", Mode: " + p.getMode());
// TODO: 07/06/17  save sleep data
//				SleepData sleepData = new SleepData(null, sleepPacket.getYear() + 2000, sleepPacket.getMonth(), sleepPacket.getDay(),
//						p.getMinutes(), p.getMode(), new Date());
//				mGlobalGreenDAO.saveSleepData(sleepData);
                //mCallback.onSleepDataReceive(sleepData);
            }
            sendMessage(MSG_RECEIVE_SLEEP_INFO, sleep, -1, -1);
        }

        @Override
        public void onSportDataCmdHistorySyncBegin() {
            if (D) Log.d(TAG, "onSportDataCmdHistorySyncBegin");
            updateWristState(STATE_WRIST_SYNC_HISTORY_DATA);
        }

        @Override
        public void onSportDataCmdHistorySyncEnd(final ApplicationLayerTodaySumSportPacket packet) {
            if (D) Log.d(TAG, "onSportDataCmdHistorySyncEnd");

            isNeedWaitForResponse = false;
            // Adjust data
            if (packet != null) {
                if (D)
                    Log.d(TAG, "onSportDataCmdHistorySyncEnd, pakect.getOffset()" + packet.getOffset()
                            + ", pakect.getTotalStep()" + packet.getTotalStep()
                            + ", pakect.getTotalCalory()" + packet.getTotalCalory()
                            + ", pakect.getTotalDistance()" + packet.getTotalDistance());
                // Here need wait a while, because of save data to database need a while.
                try {
                    Thread.sleep(100);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
//				WristbandCalculator.adjustTodayTotalStepDataNew(mContext, packet);
            }

//			if(BmobControlManager.getInstance().checkAPKWorkType()
//					&& BmobControlManager.getInstance().isNetworkConnected()) {
//				if(!isInSyncDataToService) {
//					isInSyncDataToService = true;
//					new Thread(new Runnable() {
//						@Override
//						public void run() {
//							// Need to sync data to the server, while sync end
//							//BmobDataSyncManager.syncDatatoServer(mContext, new BmobDataSyncManager.SyncListen() {
//							BmobDataSyncManager.syncDatatoServerUserCloudMethod(mContext, new BmobDataSyncManager.SyncListen() {
//								@Override
//								public void onSyncDone(BmobException e) {
//									if (D)
//										Log.d(TAG, "onSyncDone, e: " + (e == null ? "none" : e.getMessage()));
//
//									isInSyncDataToService = false;
//								}
//							});
//
//
//						}
//					}).start();
//				}
//			}
            mHandler.post(new Runnable() {
                @Override
                public void run() {
                    synchronized (mCallbacks) {
                        for (ControlManagerCallback callback : mCallbacks) {
                            callback.onSportDataCmdHistorySyncEnd(packet);
                        }
                    }

                }
            });
            sendSyncDataBroadcast();
            updateWristState(STATE_WRIST_SYNC_DATA);

        }

        @Override
        public void onSportDataCmdHrpData(final ApplicationLayerHrpPacket hrp) {
            if (D) Log.d(TAG, "onSportDataCmdHrpData");
            ApplicationLayerHrpPacket hrpPacket = hrp;
            if (D) Log.d(TAG, "Receive a hrp packet, Year: " + (hrpPacket.getYear() + 2000) +
                    ", Month: " + hrpPacket.getMonth() +
                    ", Day: " + hrpPacket.getDay() +
                    ", Item count: " + hrpPacket.getItemCount());
            for (ApplicationLayerHrpItemPacket p : hrpPacket.getHrpItems()) {
                if (D) Log.d(TAG, "Find a hrp item, Minutes: " + p.getMinutes() +
                        ", Value: " + p.getValue());
// TODO: 07/06/17 save heart data
//				HrpData hrpData = new HrpData(null, hrpPacket.getYear() + 2000, hrpPacket.getMonth(), hrpPacket.getDay(),
//						p.getMinutes(), p.getValue(), new Date());
//				mGlobalGreenDAO.saveHrpData(hrpData);
            }
            sendMessage(MSG_RECEIVE_HRP_INFO, hrp, -1, -1);
        }

        @Override
        public void onSportDataCmdDeviceCancelSingleHrpRead() {
            if (D) Log.d(TAG, "onSportDataCmdDeviceCancelSingleHrpRead");
            sendMessage(MSG_RECEIVE_HRP_DEVICE_CANCEL_SINGLE_READ, null, -1, -1);
        }

        @Override
        public void onSportDataCmdHrpContinueParamRsp(boolean enable, int interval) {
            if (D)
                Log.d(TAG, "onSportDataCmdHrpContinueParamRsp, enable: " + enable + ", interval: " + interval);
            SPWristbandConfigInfo.setContinueHrpControl(mContext, enable);
//            if (enable) {
            // Current didn't allow remote change us.
            //SPWristbandConfigInfo.setContinueHrpControlInterval(mContext, interval);
//            }
            sendMessage(MSG_RECEIVE_HRP_CONTINUE_PARAM_RSP, null, -1, -1);
        }

        @Override
        public void onTakePhotoRsp() {
            if (D) Log.d(TAG, "onTakePhotoRsp");
            sendMessage(MSG_RECEIVE_TAKE_PHOTO_RSP, null, -1, -1);
        }

        @Override
        public void onFACCmdSensorData(final ApplicationLayerFacSensorPacket sensor) {
            if (D) Log.d(TAG, "onFACCmdSensorData");
            sendMessage(MSG_RECEIVE_FAC_SENSOR_INFO, sensor, -1, -1);
        }

        @Override
        public void onBondCmdRequestBond(final byte status) {
            if (D) Log.d(TAG, "onBondCmdRequestBond, status: " + status);
            // bond right
//            if (status == ApplicationLayer.BOND_RSP_SUCCESS) {
//                mBondResponse = true;
//            }
//            // bond error
//            else {
//                mBondResponse = false;
//            }

            mBondResponse = (status == ApplicationLayer.BOND_RSP_SUCCESS);

            synchronized (mRequestResponseLock) {
                isResponseCome = true;
                isNeedWaitForResponse = false;
                mRequestResponseLock.notifyAll();
            }
        }

        @Override
        public void onBondCmdRequestLogin(final byte status) {
            if (D) Log.d(TAG, "onBondCmdRequestLogin, status: " + status);
            // Login right
            if (status == LOGIN_RSP_SUCCESS
                    || status == ApplicationLayer.LOGIN_LOSS_LOGIN_INFO) {
                mLoginResponseStatus = status;
                mLoginResponse = true;
            }
            // Login error
            else {
                mLoginResponse = false;
            }
            synchronized (mRequestResponseLock) {
                isResponseCome = true;
                isNeedWaitForResponse = false;
                mRequestResponseLock.notifyAll();
            }
        }

        public void onEndCallReceived() {
            if (D) Log.d(TAG, "onEndCallReceived");
            endCall();
        }

        @Override
        public void onLogCmdStart(final long logLength) {
            if (D) Log.d(TAG, "onLogCmdStart");
            updateWristState(STATE_WRIST_SYNC_LOG_DATA);
            sendMessage(MSG_RECEIVE_LOG_START, logLength, -1, -1);
        }

        @Override
        public void onLogCmdEnd() {
            if (D) Log.d(TAG, "onLogCmdEnd");
            updateWristState(STATE_WRIST_SYNC_DATA);
            sendMessage(MSG_RECEIVE_LOG_END, null, -1, -1);
        }

        @Override
        public void onLogCmdRsp(final ApplicationLayerLogResponsePacket packet) {
            if (D) Log.d(TAG, "onLogCmdRsp");
            sendMessage(MSG_RECEIVE_LOG_RSP, packet, -1, -1);
        }

        @Override
        public void onCommandSend(final boolean status, byte command, byte key) {
            if (D)
                Log.d(TAG, "onCommandSend, status: " + status + ", command: " + command + ", key: " + key);
            // if command send not right(no ACK). we just close it, and think connection is wrong.
            // Or, we can try to reconnect, or do other things.
            if (!status) {
                isCommandSendOk = false;
                sendErrorMessage(ERROR_CODE_COMMAND_SEND_ERROR);
                //mApplicationLayer.close(); // error
            } else {
                isCommandSendOk = true;
                if (command == ApplicationLayer.CMD_FACTORY_TEST) {
                    if (key == ApplicationLayer.KEY_FAC_TEST_ENTER_SPUER_KEY) {
                        updateWristState(STATE_WRIST_ENTER_TEST_MODE);
                    } else if (key == ApplicationLayer.KEY_FAC_TEST_LEAVE_SPUER_KEY) {
                        updateWristState(STATE_WRIST_INITIAL);
                    }
                }
            }
            synchronized (mCommandSendLock) {
                isCommandSend = true;
                mCommandSendLock.notifyAll();
            }
        }


        @Override
        public void onNameReceive(final String data) {
            sendMessage(MSG_RECEIVE_DEVICE_NAME_INFO, data, -1, -1);
            synchronized (mCommandSendLock) {
                isCommandSend = true;
                mCommandSendLock.notifyAll();
            }
        }
    };

    private void sendErrorMessage(int error) {
        sendMessage(MSG_ERROR, null, error, -1);
    }


    private void updateWristState(int state) {
        LogUtils.d(TAG, ">>>>>>>>>>>> state " + state);
        // update the wrist state
        mWristState = state;
        sendMessage(MSG_WRIST_STATE_CHANGED, null, mWristState, -1);
    }

    /**
     *  
     *      * 挂断电话 
     *      
     */
    private void endCall() {
        Class<TelephonyManager> c = TelephonyManager.class;
        TelephonyManager telMgr = (TelephonyManager) mContext.getSystemService(Service.TELEPHONY_SERVICE);
        if (telMgr.getCallState() == TelephonyManager.CALL_STATE_RINGING) {
            try {
                Method getITelephonyMethod = c.getDeclaredMethod("getITelephony", (Class[]) null);
                getITelephonyMethod.setAccessible(true);
                // TODO: 07/06/17 ITelephony is a AIDL
//				ITelephony iTelephony = null;
//				Log.e(TAG, "End call, 111.");
//				iTelephony = (ITelephony) getITelephonyMethod.invoke(telMgr, (Object[]) null);
//				iTelephony.endCall();
            } catch (Exception e) {
                Log.e(TAG, "Fail to answer ring call.", e);
            }
        }
    }

    /**
     * send message
     *
     * @param msgType Type message type
     * @param obj     object sent with the message set to null if not used
     * @param arg1    parameter sent with the message, set to -1 if not used
     * @param arg2    parameter sent with the message, set to -1 if not used
     **/
    private void sendMessage(int msgType, Object obj, int arg1, int arg2) {
        if (mHandler != null) {
            //	Message msg = new Message();
            Message msg = Message.obtain();
            msg.what = msgType;
            if (arg1 != -1) {
                msg.arg1 = arg1;
            }
            if (arg2 != -1) {
                msg.arg2 = arg2;
            }
            if (null != obj) {
                msg.obj = obj;
            }
            mHandler.sendMessage(msg);
        } else {
            if (D) Log.e(TAG, "handler is null, can't send message");
        }
    }

    @Override
    public void onBatteryValueReceive(int value) {
        if (D) Log.d(TAG, "onBatteryValueReceive, value: " + value);
        sendMessage(MSG_RECEIVE_BATTERY_INFO, null, value, -1);
    }

    @Override
    public void onBatteryValueChanged(int value) {
        if (D) Log.d(TAG, "onBatteryValueChanged, value: " + value);
        sendMessage(MSG_RECEIVE_BATTERY_CHANGE_INFO, null, value, -1);
    }

    @Override
    public void onHrpValueReceive(int value) {
        if (D) Log.d(TAG, "onHrpValueReceive, value: " + value);
        sendMessage(MSG_RECEIVE_HRP_INFO, null, value, -1);
    }

    private long mLastOtherNotifySendTime = 0;

    private void setLastOtherNotifySendTime() {
        mLastOtherNotifySendTime = System.currentTimeMillis();
    }

    private boolean checkLastOtherNotifySendTime() {
        // Diff must big then 300ms, to make sure not too much notify
        if (Math.abs(mLastOtherNotifySendTime - System.currentTimeMillis()) > 300) {
            return true;
        }
        return false;
    }

    @Override
    public void onBroadcastCome(int type, final String show) {
        if (D) Log.d(TAG, "onBroadcastCome, type: " + type);
        if (isConnect()
                //&& isReady()
                && ((mWristState == STATE_WRIST_LOGIN) || (mWristState == STATE_WRIST_SYNC_DATA))
                && !ConnectManager.getInstance().isInLogin()) {
            switch (type) {
                case NotifyBroadcastReceive.BROADCAST_CALL_WAIT:
                    if (SPWristbandConfigInfo.getNotifyCallFlag(mContext)) {
                        new Thread(new Runnable() {
                            @Override
                            public void run() {
                                // send Call notify
                                //sendCallNotifyInfo();
                                sendCallNotifyInfo(show);
                            }
                        }).start();
                    }
                    break;
                case NotifyBroadcastReceive.BROADCAST_CALL_ACC:
                    if (SPWristbandConfigInfo.getNotifyCallFlag(mContext)) {
                        new Thread(new Runnable() {
                            @Override
                            public void run() {
                                // send Call notify
                                sendCallAcceptNotifyInfo();
                            }
                        }).start();
                    }
                    break;
                case NotifyBroadcastReceive.BROADCAST_CALL_REJ:
                    if (SPWristbandConfigInfo.getNotifyCallFlag(mContext)) {
                        new Thread(new Runnable() {
                            @Override
                            public void run() {
                                // send Call notify
                                sendCallRejectNotifyInfo();
                            }
                        }).start();

                    }
                    break;
                case NotifyBroadcastReceive.BROADCAST_SMS:
                    if (SPWristbandConfigInfo.getNotifyMessageFlag(mContext)) {
                        new Thread(new Runnable() {
                            @Override
                            public void run() {
                                // send Message notify
                                sendOtherNotifyInfo(ApplicationLayer.OTHER_NOTIFY_INFO_MESSAGE, show);
                            }
                        }).start();
                    }
                    break;
                case NotifyBroadcastReceive.BROADCAST_QQ:
                    if (SPWristbandConfigInfo.getNotifyQQFlag(mContext)) {
                        if (!checkLastOtherNotifySendTime()) {
                            if (D)
                                Log.w(TAG, "Other notify receive too fast, didn't need to send again.");
                            return;
                        }
                        new Thread(new Runnable() {
                            @Override
                            public void run() {
                                setLastOtherNotifySendTime();
                                // send Message notify
                                sendOtherNotifyInfo(ApplicationLayer.OTHER_NOTIFY_INFO_QQ, show);
                            }
                        }).start();
                    }
                    break;
                case NotifyBroadcastReceive.BROADCAST_WECHAT:
                    if (SPWristbandConfigInfo.getNotifyWechatFlag(mContext)) {
                        if (!checkLastOtherNotifySendTime()) {
                            if (D)
                                Log.w(TAG, "Other notify receive too fast, didn't need to send again.");
                            return;
                        }
                        new Thread(new Runnable() {
                            @Override
                            public void run() {
                                setLastOtherNotifySendTime();
                                // send Message notify
                                sendOtherNotifyInfo(ApplicationLayer.OTHER_NOTIFY_INFO_WECHAT, show);
                            }
                        }).start();
                    }
                    break;
            }
        } else {
            if (D) Log.e(TAG, "Receive broadcast with state error, do nothing!");
        }
    }


    //    private MediaPlayer mMediaPlayer;
    // for Vibrator
//    private Vibrator mVibrator;
    //    private AlertDialog mAlertDialog;
//    private boolean isInAlarm = false;
    // Alarm timer
//    Handler mAlarmSuperHandler = new Handler();
//    Runnable mAlarmSuperTask = new Runnable() {
//        @Override
//        public void run() {
//            // TODO Auto-generated method stub
//            if (D) Log.w(TAG, "Wait Alarm Timeout");
//            // stop timer
//            stopAlarm();
//        }
//    };

//    private void playAlarm() {
//        if (D) Log.e(TAG, "playAlarm");
//        int alarmTime;
//        String musicPath;
//        isInAlarm = true;
//
//        alarmTime = SPWristbandConfigInfo.getLostAlarmTime(mContext);
//        musicPath = SPWristbandConfigInfo.getLostAlarmMusic(mContext);
//        try {
//            if (musicPath != null) {
//                mMediaPlayer.setDataSource(musicPath);
//                if (D) Log.e(TAG, "load music, path: " + musicPath);
//            } else {
//                Uri uri = Uri.parse("android.resource://com.realsil.android.wristbanddemo/" + R.raw.alarm);
//                //AssetFileDescriptor fileDescriptor = mContext.getAssets().openFd("alarm.wav");
//                if (D) Log.d(TAG, "load music, uri: " + uri.toString());
//                mMediaPlayer.setDataSource(mContext, uri);
//            }
//            mMediaPlayer.prepare();
//            mMediaPlayer.setLooping(true);
//            mMediaPlayer.start();
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//        long[] pattern = new long[]{200, 200, 200, 200, 200};
//        mVibrator.vibrate(pattern, 0);
//        //mVibrator.vibrate(alarmTime * 1000);
//        mAlarmSuperHandler.postDelayed(mAlarmSuperTask, alarmTime * 1000);
//    }

//    private void stopAlarm() {
//        isInAlarm = false;
////        mMediaPlayer.stop();
//        //mSoundPool.autoPause();
//        mVibrator.cancel();
//        if (mAlertDialog != null) {
//            mAlertDialog.dismiss();
//        }
//        mAlarmSuperHandler.removeCallbacks(mAlarmSuperTask);
//    }

    @Override
    public void onVersionRead(int appVersion, int patchVersion) {
        if (D)
            Log.d(TAG, "onVersionRead, appVersion: " + appVersion + ", patchVersion: " + patchVersion);
        sendMessage(MSG_RECEIVE_DFU_VERSION_INFO, null, appVersion, patchVersion);

        synchronized (mCommandSendLock) {
            isCommandSendOk = true;
            isCommandSend = true;
            mCommandSendLock.notifyAll();
        }
    }

    @Override
    public void noNewVersion(int code, String message) {
        synchronized (mCallbacks) {
            // do something
            for (ControlManagerCallback callback : mCallbacks) {
                callback.noNewVersion(code, message);
            }
        }
    }

    @Override
    public void hasNewVersion(String description, String version) {
        synchronized (mCallbacks) {
            // do something
            for (ControlManagerCallback callback : mCallbacks) {
                callback.hasNewVersion(description, version);
            }
        }
    }


    @Override
    public void downloadProgress(int progressRate) {
        // show state
        synchronized (mCallbacks) {
            // do something
            for (ControlManagerCallback callback : mCallbacks) {
                callback.downloadProgress(progressRate);
            }
        }
    }

    @Override
    public void netWorkError(Throwable e) {
        // show state
        synchronized (mCallbacks) {
            // do something
            for (ControlManagerCallback callback : mCallbacks) {
                callback.downloadError();
            }
        }
    }

    @Override
    public void downloadComplete(String fwPath) {
        synchronized (mCallbacks) {
            // do something
            for (ControlManagerCallback callback : mCallbacks) {
                callback.downloadComplete(fwPath);
            }
        }
    }

    @Override
    public void onLinkLossValueReceive(boolean value) {
        if (D) Log.d(TAG, "onLinkLossValueReceive, value: " + value);
        SPWristbandConfigInfo.setControlSwitchLost(mContext, value);
        synchronized (mCommandSendLock) {
            isCommandSendOk = true;
            isCommandSend = true;
            mCommandSendLock.notifyAll();
        }
    }

    private boolean isNotifyManageEnabled() {
        if (D) Log.d(TAG, "isNotifyManageEnabled");
        String pkgName = mContext.getPackageName();
        final String flat = Settings.Secure.getString(mContext.getContentResolver(),
                ENABLED_NOTIFICATION_LISTENERS);
        if (!TextUtils.isEmpty(flat)) {
            final String[] names = flat.split(":");
            for (int i = 0; i < names.length; i++) {
                final ComponentName cn = ComponentName.unflattenFromString(names[i]);
                if (cn != null) {
                    if (TextUtils.equals(pkgName, cn.getPackageName())) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    private void sendSyncDataBroadcast() {
        Intent intent = new Intent();
        intent.setAction(ACTION_SYNC_DATA_OK);
        mContext.sendBroadcast(intent);
    }
}
