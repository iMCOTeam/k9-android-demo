package com.imco.fwota;

/**
 * Created by mai on 17-7-10.
 */

public class FwBean {
    public String vendor;
    public String model;
    public String fwType;
    public String serial;
    public String fwVersion;

    public FwBean(String vendor, String model, String fwType, String serial, String fwVersion) {
        this.vendor = vendor;
        this.model = model;
        this.fwType = fwType;
        this.serial = serial;
        this.fwVersion = fwVersion;
    }
}
