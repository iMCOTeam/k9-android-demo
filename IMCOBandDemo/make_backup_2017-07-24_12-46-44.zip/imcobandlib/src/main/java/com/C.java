package com;

/**
 * Created by mai on 17-7-11.
 */

public class C {
    public static final String FW_TYPE_APP= "app";
    public static final String FW_TYPE_PATCH= "patch";
}
