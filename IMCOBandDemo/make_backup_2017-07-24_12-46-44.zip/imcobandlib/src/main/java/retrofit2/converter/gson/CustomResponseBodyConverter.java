package retrofit2.converter.gson;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonPrimitive;
import com.google.gson.TypeAdapter;
import com.imco.fwota.FwResultBean;
import com.imco.utils.LogUtils;

import java.io.IOException;
import java.lang.reflect.Type;

import okhttp3.ResponseBody;
import retrofit2.Converter;

/**
 * 因为后台在没有更新和有更新时返回的json格式不一致，这里自定义一个Converter对特定的json进行解析
 * Created by mai on 17-7-14.
 */

public class CustomResponseBodyConverter<T> implements Converter<ResponseBody, T> {

    private final Gson gson;
    private final TypeAdapter<T> adapter;
    private final Type mType;

    CustomResponseBodyConverter(Gson gson, TypeAdapter<T> adapter, Type type) {
        this.gson = gson;
        this.adapter = adapter;
        this.mType = type;
    }

    @Override public T convert(ResponseBody value) throws IOException {
        String body = value.string();
        JsonObject jsonObject = new JsonParser().parse(body).getAsJsonObject();
        JsonPrimitive jsonPrimitive = jsonObject.getAsJsonPrimitive("code");
        int code = 0;
        if (jsonPrimitive != null) {
            code = jsonPrimitive.getAsInt();
            if (code == 0) {
                // Have new firmware version
                return adapter.fromJson(body);
            } else {
                // not new firmware version
                LogUtils.d("T t = null;");
                T t = null;
                try {
                    // 通过反射获取泛型的实例对象
                    Class<T> clazz = (Class<T>) mType;
                    t = clazz.newInstance();
                } catch (Exception e) {
                    e.printStackTrace();
                }
                ((FwResultBean)t).code = code;
                ((FwResultBean)t).errorStr = gson.fromJson(jsonObject.getAsJsonPrimitive("payload"), String.class);
                return t;
            }
        } else {
            return adapter.fromJson(body);
        }
    }

//        String json = value.string();
//        JsonObject jsonObject = new JsonParser().parse(json).getAsJsonObject();
//        // 解析code
//        JsonPrimitive jsonPrimitive = jsonObject.getAsJsonPrimitive("code");
//        int code = 0;
//        if (jsonPrimitive != null) {
//            code = jsonPrimitive.getAsInt();
//        }
//
//        T t = null;
//        try {
//            // 通过反射获取泛型的实例对象
//
//            t = (T) t.getClass().newInstance();
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//
//        if (code == 1) {
//            t.errorStr = gson.fromJson(jsonObject.getAsJsonArray("payload"), String.class);
//        } else {
//            return gson.fromJson(json, type);
//        }
//        return t;
//    }
}
