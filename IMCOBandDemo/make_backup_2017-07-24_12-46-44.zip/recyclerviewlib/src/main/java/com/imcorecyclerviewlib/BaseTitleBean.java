package com.imcorecyclerviewlib;

/**
 * Created by mai on 17-5-2.
 */

public class BaseTitleBean {
    public String title;
}
