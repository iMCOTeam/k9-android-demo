# Manager Applications Release Notes

### Revision v1.0.0 (14/7/2017)

#### New Feature
* 增加OTA升级
